import React, { useState, useEffect, useRef } from "react";
import { 
  Mic, 
  MicOff, 
  Send, 
  Tv, 
  Upload, 
  RotateCcw,
  Volume2,
  VolumeX,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  Settings,
  MessageSquare,
  HelpCircle,
  Video,
  Cloud,
  Database,
  Folder,
  FolderOpen,
  Chrome,
  LogOut,
  Eye,
  EyeOff,
  Copy,
  Check,
  Trash2,
  Play,
  Image as ImageIcon,
  Maximize,
  Minimize,
  Smartphone,
  ShieldAlert,
  Radio,
  CheckCircle2,
  RefreshCw
} from "lucide-react";
import { Trigger } from "./types";

interface CustomQuestion {
  id: string;
  phrase: string;
  videoUrl: string;
  videoName: string;
}

export default function App() {
  // Navigation: state to change between the interactive screen "chat" and "settings"
  const [activeTab, setActiveTab] = useState<"chat" | "settings">("chat");

  // Dynamic Questions List State
  const [questions, setQuestions] = useState<CustomQuestion[]>(() => {
    try {
      const saved = localStorage.getItem("eco_custom_questions");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((q: any) => ({
            id: q.id,
            phrase: q.phrase || "",
            videoUrl: "", // Object/Blob URLs expire across page refreshes
            videoName: q.videoName || ""
          }));
        }
      }
    } catch (e) {
      console.error("Failed to load eco_custom_questions:", e);
    }

    // Default 2 questions
    return [
      { id: "questionA", phrase: "mostrar natureza", videoUrl: "", videoName: "" },
      { id: "questionB", phrase: "mostrar chuva", videoUrl: "", videoName: "" }
    ];
  });

  // Local object URLs for video files (stored in state for active session)
  const [introUrl, setIntroUrl] = useState<string>("");
  const [introName, setIntroName] = useState(() => localStorage.getItem("eco_intro_name") || "");

  // Active slot corresponds to either "intro" or any question id
  const [activeVideoSlot, setActiveVideoSlot] = useState<string>("intro");

  // Chat conversation state
  const [inputText, setInputText] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [lastSpeechDetected, setLastSpeechDetected] = useState<string>("");
  const [realtimeSpeech, setRealtimeSpeech] = useState<string>("");
  const [speechError, setSpeechError] = useState("");
  const [aiResponseText, setAiResponseText] = useState<string>(
    "Canal pronto. Clique no microfone ou digite abaixo para falar um dos comandos configurados."
  );

  // Playback settings
  const [videoMuted, setVideoMuted] = useState(true);
  const [videoPlayError, setVideoPlayError] = useState<string>("");
  const [isListening, setIsListening] = useState(false);
  const [showReplayPrompt, setShowReplayPrompt] = useState(false);
  const [viewedSlots, setViewedSlots] = useState<string[]>([]);
  const [videoFinished, setVideoFinished] = useState<boolean>(false);

  // Advanced Microphone & Audio States (for 100% Mobile & Desktop Compatibility)
  const [isRecordingMedia, setIsRecordingMedia] = useState<boolean>(false);
  const [isTranscribing, setIsTranscribing] = useState<boolean>(false);
  const [audioLevel, setAudioLevel] = useState<number>(0);
  const [recordingDuration, setRecordingDuration] = useState<number>(0);
  const [micPermission, setMicPermission] = useState<"unknown" | "granted" | "denied" | "prompt" | "unsupported">("unknown");
  const [showMicModal, setShowMicModal] = useState<boolean>(false);
  const [preferredSpeechEngine, setPreferredSpeechEngine] = useState<"auto" | "gemini" | "native">(() => {
    const saved = localStorage.getItem("eco_speech_engine");
    if (saved === "gemini" || saved === "native" || saved === "auto") return saved;
    return "auto";
  });

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const recordingIntervalRef = useRef<any>(null);
  const autoStopTimeoutRef = useRef<any>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  
  // Mobile & Fullscreen States
  const [isMobile, setIsMobile] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      return window.innerWidth < 768;
    }
    return false;
  });

  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  const [mobileFullscreenAuto, setMobileFullscreenAuto] = useState<boolean>(() => {
    const saved = localStorage.getItem("eco_mobile_fullscreen_auto");
    return saved !== null ? saved === "true" : true;
  });

  const [videoFit, setVideoFit] = useState<"contain" | "cover">(() => {
    const saved = localStorage.getItem("eco_video_fit");
    if (saved === "contain" || saved === "cover") return saved;
    // Padrão: Preencher a tela (especialmente no mobile conforme solicitado)
    return "cover";
  });

  useEffect(() => {
    localStorage.setItem("eco_video_fit", videoFit);
  }, [videoFit]);

  useEffect(() => {
    localStorage.setItem("eco_mobile_fullscreen_auto", String(mobileFullscreenAuto));
  }, [mobileFullscreenAuto]);

  useEffect(() => {
    localStorage.setItem("eco_speech_engine", preferredSpeechEngine);
  }, [preferredSpeechEngine]);

  // Check initial microphone permission status if supported by the browser
  useEffect(() => {
    if (typeof navigator !== "undefined" && navigator.permissions && (navigator.permissions as any).query) {
      try {
        navigator.permissions.query({ name: "microphone" as PermissionName })
          .then((status) => {
            setMicPermission(status.state as any);
            status.onchange = () => {
              setMicPermission(status.state as any);
            };
          })
          .catch(() => {
            setMicPermission("unknown");
          });
      } catch (_) {
        setMicPermission("unknown");
      }
    }
  }, []);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    const handleFsChange = () => {
      if (!document.fullscreenElement && isFullscreen) {
        setIsFullscreen(false);
      }
    };
    document.addEventListener("fullscreenchange", handleFsChange);
    document.addEventListener("webkitfullscreenchange", handleFsChange);
    return () => {
      document.removeEventListener("fullscreenchange", handleFsChange);
      document.removeEventListener("webkitfullscreenchange", handleFsChange);
    };
  }, [isFullscreen]);

  const videoContainerRef = useRef<HTMLDivElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const lastTapRef = useRef<number>(0);

  // Automatic Fullscreen Management:
  // "Quando o vídeo começar a ferramenta por si só deve colocar o vídeo em tela cheia e depois que terminar voltar para mostrar os gatilhos que podem ser usados, mas sempre depois de uma pergunta o vídeo deve começar em tela cheia"
  const enterFullscreenAuto = async () => {
    setIsFullscreen(true);
    try {
      if (videoContainerRef.current && !document.fullscreenElement) {
        if (videoContainerRef.current.requestFullscreen) {
          await videoContainerRef.current.requestFullscreen().catch(() => {});
        } else if ((videoRef.current as any)?.webkitEnterFullscreen) {
          (videoRef.current as any).webkitEnterFullscreen();
        }
      }
    } catch (err) {
      console.info("Using CSS fixed viewport fullscreen:", err);
    }
  };

  const exitFullscreenAuto = async () => {
    setIsFullscreen(false);
    try {
      if (document.fullscreenElement && document.exitFullscreen) {
        await document.exitFullscreen().catch(() => {});
      } else if ((document as any).webkitFullscreenElement && (document as any).webkitExitFullscreen) {
        await (document as any).webkitExitFullscreen().catch(() => {});
      }
    } catch (err) {
      console.info("Exit full screen note:", err);
    }
  };

  const toggleFullscreen = async () => {
    if (!isFullscreen) {
      await enterFullscreenAuto();
    } else {
      await exitFullscreenAuto();
    }
  };

  // Centralized Video Slot Trigger: Starts any video (question or intro) in FULL SCREEN, resets state, and auto-plays
  const triggerVideoSlot = (slotId: string, announceText?: string) => {
    setHasStarted(true);
    setVideoFinished(false);
    setActiveVideoSlot(slotId);
    if (announceText) {
      setAiResponseText(announceText);
    }

    // Automatically enter full screen whenever video starts or after a question
    enterFullscreenAuto();

    setTimeout(() => {
      if (videoRef.current) {
        videoRef.current.currentTime = 0;
        const p = videoRef.current.play();
        if (p !== undefined) {
          p.catch(err => console.warn("Video auto-play catch:", err));
        }
      }
    }, 70);
  };

  const handleVideoTouch = () => {
    const now = Date.now();
    if (now - lastTapRef.current < 300) {
      toggleFullscreen();
    }
    lastTapRef.current = now;
  };

  const [hidePanels, setHidePanels] = useState<boolean>(false);
  const [hasStarted, setHasStarted] = useState<boolean>(false);
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);

  // Background Image State (Amazon Rainforest Wildlife)
  const [showBgImage, setShowBgImage] = useState<boolean>(() => {
    const saved = localStorage.getItem("eco_show_bg_image");
    return saved !== null ? saved === "true" : true;
  });
  const [bgOpacity, setBgOpacity] = useState<number>(() => {
    const saved = localStorage.getItem("eco_bg_opacity");
    return saved !== null ? Number(saved) : 35;
  });

  useEffect(() => {
    localStorage.setItem("eco_show_bg_image", String(showBgImage));
  }, [showBgImage]);

  useEffect(() => {
    localStorage.setItem("eco_bg_opacity", String(bgOpacity));
  }, [bgOpacity]);

  // Web Speech API references
  const recognitionRef = useRef<any>(null);

  // Helper helper to clean and evaluate similarity between recognized text and target phrases
  const getFuzzyMatchScore = (input: string, targetPhrase: string): number => {
    if (!input || !targetPhrase) return 0;
    
    const cleanString = (s: string) => {
      return s
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "") // remove accents
        .replace(/[^a-z0-9\s]/g, "") // remove punctuation
        .trim();
    };

    const inputClean = cleanString(input);
    const targetClean = cleanString(targetPhrase);

    if (!inputClean || !targetClean) return 0;

    // Exact match
    if (inputClean === targetClean) return 1.0;

    // Substring contains
    if (inputClean.includes(targetClean) || targetClean.includes(inputClean)) {
      return 0.95;
    }

    // Split words to see the intersection of keywords (plurals and verb stems)
    const inputWords = inputClean.split(/\s+/).filter(w => w.length > 1);
    const targetWords = targetClean.split(/\s+/).filter(w => w.length > 2);

    if (targetWords.length === 0) return 0;

    let matchCount = 0;
    for (const tWord of targetWords) {
      const matched = inputWords.some(iWord => {
        if (iWord === tWord) return true;
        // Check partial word prefixes to match e.g. "mostra" and "mostrar", "chuva" and "chuvas", etc.
        const minLen = Math.min(tWord.length, iWord.length);
        if (minLen >= 4) {
          const prefixT = tWord.substring(0, 4);
          const prefixI = iWord.substring(0, 4);
          if (prefixT === prefixI) return true;
        }
        return false;
      });
      if (matched) matchCount++;
    }

    return matchCount / targetWords.length;
  };

  // Sync state metadata to localStorage
  useEffect(() => {
    localStorage.setItem("eco_intro_name", introName);
    
    const configToSave = questions.map(q => ({
      id: q.id,
      phrase: q.phrase,
      videoName: q.videoName
    }));
    localStorage.setItem("eco_custom_questions", JSON.stringify(configToSave));
  }, [questions, introName]);

  // Dynamic audio and speech recognition lifecycle is managed on-demand via toggleListening

  // Play and reload helper triggered on video changes
  const activeVideoUrl = (() => {
    if (activeVideoSlot === "intro") {
      return introUrl;
    }
    const match = questions.find(q => q.id === activeVideoSlot);
    if (match) {
      return match.videoUrl;
    }
    return "";
  })();

  useEffect(() => {
    setShowReplayPrompt(false);
    setVideoFinished(false);
    if (videoRef.current) {
      const v = videoRef.current;
      setVideoPlayError("");
      try {
        v.load();
        const playPromise = v.play();
        if (playPromise !== undefined) {
          playPromise.catch((err) => {
            console.warn("Automatic play delayed/prevented:", err);
          });
        }
      } catch (err) {
        console.error("Video load error:", err);
      }
    }
  }, [activeVideoSlot, activeVideoUrl]);

  // Handle local video files selection
  const handleFileChange = (slotId: string, file: File) => {
    const url = URL.createObjectURL(file);
    if (slotId === "intro") {
      setIntroUrl(url);
      setIntroName(file.name);
      setActiveVideoSlot("intro");
    } else {
      setQuestions(prev => prev.map(q => {
        if (q.id === slotId) {
          return { ...q, videoUrl: url, videoName: file.name };
        }
        return q;
      }));
      setActiveVideoSlot(slotId);
    }
  };

  // Add questions helper
  const addQuestion = () => {
    const newId = `trigger_${Date.now()}`;
    setQuestions(prev => [
      ...prev,
      {
        id: newId,
        phrase: `nova resposta ${prev.length + 1}`,
        videoUrl: "",
        videoName: ""
      }
    ]);
  };

  // Remove question helper
  const removeQuestion = (id: string) => {
    setConfirmModal({
      isOpen: true,
      title: "Excluir Gatilho",
      message: "Deseja mesmo excluir este gatilho de ativação por voz? Essa ação não pode ser desfeita.",
      onConfirm: () => {
        setQuestions(prev => prev.filter(q => q.id !== id));
        if (activeVideoSlot === id) {
          setActiveVideoSlot("intro");
        }
      }
    });
  };

  const updateQuestionPhrase = (id: string, phrase: string) => {
    setQuestions(prev => prev.map(q => {
      if (q.id === id) {
        return { ...q, phrase };
      }
      return q;
    }));
  };

  const getActiveVideoUrl = () => {
    return activeVideoUrl;
  };

  const getActiveVideoTitle = () => {
    if (activeVideoSlot === "intro") return `APRESENTAÇÃO INICIAL: ${introName || "Sem Arquivo"}`;
    const match = questions.find(q => q.id === activeVideoSlot);
    if (match) {
      return `PROJEÇÃO: ${match.phrase.toUpperCase()} (${match.videoName || "Sem Arquivo"})`;
    }
    return "APRESENTAÇÃO INICIAL";
  };

  const isIntroSpecialVideo = activeVideoSlot === "intro" && (
    introName === "WhatsApp Video 2026-06-12 at 08.35.25.mp4" ||
    introName === "WhatsApp Video 2026-06-12 at 08.35.25" ||
    introName?.includes("WhatsApp Video 2026-06-12 at 08.35.25.mp4") ||
    getActiveVideoTitle() === "APRESENTAÇÃO INICIAL: WhatsApp Video 2026-06-12 at 08.35.25.mp4"
  );

  const playableSlots = [
    ...(introUrl ? ["intro"] : []),
    ...questions.filter(q => q.videoUrl).map(q => q.id)
  ];

  const allVideosPlayed = playableSlots.length > 0 && playableSlots.every(slot => viewedSlots.includes(slot));

  const resetAllTriggers = () => {
    setConfirmModal({
      isOpen: true,
      title: "Redefinir Tudo",
      message: "Deseja apagar todos os vídeos carregados e redefinir as frases de ativação para o padrão?",
      onConfirm: () => {
        setIntroUrl("");
        setIntroName("");
        setQuestions([
          { id: "questionA", phrase: "mostrar natureza", videoUrl: "", videoName: "" },
          { id: "questionB", phrase: "mostrar chuva", videoUrl: "", videoName: "" }
        ]);
        setActiveVideoSlot("intro");
        setLastSpeechDetected("");
        setRealtimeSpeech("");
        setAiResponseText("Ajustes redefinidos. Vá na janela de configurações para carregar vídeos locais.");
      }
    });
  };

  // Main voice commander parser & matcher to trigger projection shifts
  const handleIncomingCommand = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed) return;

    const lowerText = trimmed.toLowerCase();

    // Hands-free voice commands requested by the user
    if (
      lowerText.includes("rever") || 
      lowerText.includes("reassistir") || 
      lowerText.includes("reproduzir novamente") || 
      lowerText.includes("ver de novo") ||
      lowerText.includes("rever video") ||
      lowerText.includes("rever vídeo")
    ) {
      setVideoFinished(false);
      if (videoRef.current) {
        videoRef.current.currentTime = 0;
        const playPromise = videoRef.current.play();
        if (playPromise !== undefined) {
          playPromise.catch(err => console.warn("Failed to play: ", err));
        }
      }
      setAiResponseText("Vídeo reiniciado via comando de voz.");
      setIsAnalyzing(false);
      return;
    }

    if (
      lowerText.includes("iniciar do zero") || 
      lowerText.includes("iniciar do xzero") || 
      lowerText.includes("reiniciar") || 
      lowerText.includes("do zero") || 
      lowerText.includes("do xzero") || 
      lowerText.includes("iniciar do o0") || 
      lowerText.includes("do o0") ||
      lowerText.includes("começar do zero")
    ) {
      setViewedSlots([]);
      triggerVideoSlot("intro", "Visita reiniciada do zero via comando de voz.");
      setIsAnalyzing(false);
      return;
    }

    setLastSpeechDetected(trimmed);
    setInputText("");
    setIsAnalyzing(true);
    setSpeechError("");

    const virtualTriggers: Trigger[] = [
      { id: "intro", phrase: "introdução", videoUrl: introUrl, description: "Introdução ou início" },
      ...questions.map(q => ({
        id: q.id,
        phrase: q.phrase,
        videoUrl: q.videoUrl,
        description: `Pergunta: ${q.phrase}`
      }))
    ];

    try {
      // Calculate direct alignment scores with our optimized fuzzy word matcher
      const scores = questions.map(q => ({
        id: q.id,
        phrase: q.phrase,
        score: getFuzzyMatchScore(trimmed, q.phrase)
      }));

      // Common phrases for intro/home/reset
      const introPhrases = ["introducao", "introdução", "inicio", "iniciar", "voltar", "comeco", "começo", "começar", "apresentação"];
      const scoreIntro = Math.max(...introPhrases.map(p => getFuzzyMatchScore(trimmed, p)));

      // Find the highest score among questions
      const bestMatch = scores.reduce((best, curr) => curr.score > best.score ? curr : best, { id: "", phrase: "", score: 0 });

      console.log(`[Scores] Best Match: "${bestMatch.phrase}" (${bestMatch.score}) | Intro: ${scoreIntro}`);

      // We privilege clear fuzzy score matches over contacting a server (keeps app instantaneous if confident)
      if (bestMatch.score >= 0.5 && bestMatch.score >= scoreIntro) {
        triggerVideoSlot(bestMatch.id, `[Sintonia] Pergunta correspondida! Transmitindo Vídeo em tela cheia: "${bestMatch.phrase}"`);
        setIsAnalyzing(false);
        return;
      } else if (scoreIntro >= 0.5 && scoreIntro >= bestMatch.score) {
        triggerVideoSlot("intro", "[Sintonia] Voltando à apresentação inicial em tela cheia.");
        setIsAnalyzing(false);
        return;
      }

      // Query server for smart fallback matching if fuzzy metrics are ambiguous
      const response = await fetch("/api/gemini/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          input: trimmed,
          triggers: virtualTriggers
        })
      });

      if (!response.ok) {
        throw new Error("Erro de resposta do servidor de análise.");
      }

      const result = await response.json();
      const matchedId = result.matchedTriggerId;
      
      if (matchedId === "intro") {
        triggerVideoSlot("intro", result.response || "Comando de retorno correspondido. Sintonizando introdução inicial em tela cheia.");
      } else if (matchedId) {
        const matchedQuestion = questions.find(q => q.id === matchedId);
        if (matchedQuestion) {
          triggerVideoSlot(matchedId, result.response || `Entendi! Sintonizando o Vídeo em tela cheia: "${matchedQuestion.phrase}"`);
        } else {
          setAiResponseText(`Comando não identificado. Por favor, fale um comando configurado.`);
        }
      } else {
        const phrasesList = questions.map(q => `"${q.phrase}"`).join(" ou ");
        setAiResponseText(`Comando não identificado. Por favor, fale um comando configurado: ${phrasesList}.`);
      }

    } catch (err) {
      // Local strict offline fallback matcher
      const scores = questions.map(q => ({
        id: q.id,
        phrase: q.phrase,
        score: getFuzzyMatchScore(trimmed, q.phrase)
      }));
      const bestMatch = scores.reduce((best, curr) => curr.score > best.score ? curr : best, { id: "", phrase: "", score: 0 });

      if (bestMatch.score > 0.35) {
        triggerVideoSlot(bestMatch.id, `[Sintonizado] Transmitindo em tela cheia: "${bestMatch.phrase}"`);
      } else {
        const phrasesList = questions.map(q => `"${q.phrase}"`).join(" ou ");
        setAiResponseText(`Não foi possível compreender "${trimmed}". Diga exatamente ${phrasesList}.`);
      }
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Request microphone permission explicitly (triggers browser dialog on mobile iOS/Android)
  const requestMicrophonePermission = async (): Promise<boolean> => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setSpeechError("Navegador não possui suporte para acesso ao microfone.");
        setMicPermission("unsupported");
        return false;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        }
      });

      setMicPermission("granted");
      setSpeechError("");
      // Release tracks immediately
      stream.getTracks().forEach(track => track.stop());
      return true;
    } catch (err: any) {
      console.warn("Microphone permission error:", err);
      if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
        setMicPermission("denied");
        setSpeechError("Microfone bloqueado pelo navegador. Toque em 'Habilitar Microfone' para liberar.");
        setShowMicModal(true);
      } else {
        setSpeechError(`Erro no microfone: ${err.message || err.name}`);
      }
      return false;
    }
  };

  const cleanupAudioRecording = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (recordingIntervalRef.current) {
      clearInterval(recordingIntervalRef.current);
      recordingIntervalRef.current = null;
    }
    if (autoStopTimeoutRef.current) {
      clearTimeout(autoStopTimeoutRef.current);
      autoStopTimeoutRef.current = null;
    }
    if (audioContextRef.current) {
      try {
        audioContextRef.current.close();
      } catch (_) {}
      audioContextRef.current = null;
    }
    if (audioStreamRef.current) {
      try {
        audioStreamRef.current.getTracks().forEach(t => t.stop());
      } catch (_) {}
      audioStreamRef.current = null;
    }
    setAudioLevel(0);
    setIsRecordingMedia(false);
  };

  const stopMediaRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
      try {
        mediaRecorderRef.current.stop();
      } catch (err) {
        console.warn("Error stopping MediaRecorder:", err);
        cleanupAudioRecording();
        setIsListening(false);
      }
    } else {
      cleanupAudioRecording();
      setIsListening(false);
    }
  };

  const startMediaRecording = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setSpeechError("Captura de microfone indisponível neste navegador.");
        return;
      }

      setSpeechError("");
      setRealtimeSpeech("");

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        }
      });

      audioStreamRef.current = stream;
      setMicPermission("granted");
      setIsListening(true);
      setIsRecordingMedia(true);
      setRecordingDuration(0);

      // Real-time audio analyzer for visual sound feedback on mobile
      try {
        const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtxClass) {
          const ctx = new AudioCtxClass();
          const analyser = ctx.createAnalyser();
          analyser.fftSize = 128;
          analyser.smoothingTimeConstant = 0.5;
          const source = ctx.createMediaStreamSource(stream);
          source.connect(analyser);
          audioContextRef.current = ctx;

          const dataArray = new Uint8Array(analyser.frequencyBinCount);
          const tickLevel = () => {
            if (!audioStreamRef.current) return;
            analyser.getByteFrequencyData(dataArray);
            let sum = 0;
            for (let i = 0; i < dataArray.length; i++) {
              sum += dataArray[i];
            }
            const avg = sum / dataArray.length;
            const level = Math.min(100, Math.round((avg / 120) * 100));
            setAudioLevel(level);
            animationFrameRef.current = requestAnimationFrame(tickLevel);
          };
          tickLevel();
        }
      } catch (e) {
        console.warn("Audio meter setup skipped:", e);
      }

      // Check supported MIME type across mobile devices
      const candidateMimes = [
        "audio/webm;codecs=opus",
        "audio/webm",
        "audio/mp4",
        "audio/aac",
        "audio/ogg;codecs=opus"
      ];
      let selectedMime = "";
      if (typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported) {
        for (const m of candidateMimes) {
          if (MediaRecorder.isTypeSupported(m)) {
            selectedMime = m;
            break;
          }
        }
      }

      const recorder = selectedMime
        ? new MediaRecorder(stream, { mimeType: selectedMime })
        : new MediaRecorder(stream);

      audioChunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      recorder.onstop = async () => {
        const recordedMime = recorder.mimeType || selectedMime || "audio/webm";
        const chunks = [...audioChunksRef.current];
        cleanupAudioRecording();
        setIsListening(false);

        if (chunks.length === 0) {
          setSpeechError("Nenhum áudio detectado.");
          return;
        }

        const audioBlob = new Blob(chunks, { type: recordedMime });
        if (audioBlob.size < 400) {
          setSpeechError("Áudio muito curto. Fale um comando como 'mostrar natureza'.");
          return;
        }

        setIsAnalyzing(true);
        setIsTranscribing(true);
        setSpeechError("");

        try {
          const reader = new FileReader();
          reader.readAsDataURL(audioBlob);
          reader.onloadend = async () => {
            try {
              const base64Data = reader.result as string;
              const res = await fetch("/api/transcribe-audio", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  audioData: base64Data,
                  mimeType: recordedMime
                })
              });

              if (!res.ok) {
                throw new Error(`Servidor retornou status ${res.status}`);
              }

              const data = await res.json();
              setIsTranscribing(false);
              setIsAnalyzing(false);

              if (data.transcript && data.transcript.trim()) {
                const text = data.transcript.trim();
                setLastSpeechDetected(text);
                setRealtimeSpeech("");
                handleIncomingCommand(text);
              } else {
                setSpeechError("Nenhuma fala detectada no áudio gravado. Tente falar mais próximo ao celular.");
              }
            } catch (err: any) {
              console.error("Transcribe API error:", err);
              setIsTranscribing(false);
              setIsAnalyzing(false);
              setSpeechError("Não foi possível transcrever o áudio gravado.");
            }
          };
        } catch (err: any) {
          setIsTranscribing(false);
          setIsAnalyzing(false);
          setSpeechError("Erro ao processar áudio.");
        }
      };

      mediaRecorderRef.current = recorder;
      recorder.start(250);

      // Increment recording duration every second
      recordingIntervalRef.current = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);

      // Auto stop after 7 seconds if user doesn't tap again
      autoStopTimeoutRef.current = setTimeout(() => {
        if (recorder.state === "recording") {
          recorder.stop();
        }
      }, 7000);

    } catch (err: any) {
      console.warn("MediaRecorder start error:", err);
      cleanupAudioRecording();
      setIsListening(false);
      if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
        setMicPermission("denied");
        setSpeechError("Acesso ao microfone negado no celular.");
        setShowMicModal(true);
      } else {
        setSpeechError(`Erro ao abrir microfone: ${err.message || err.name}`);
      }
    }
  };

  // Native Web Speech API driver with clean per-session instantiation
  const startListeningNative = (SpeechRecognitionClass: any) => {
    try {
      if (recognitionRef.current) {
        try { recognitionRef.current.abort(); } catch (_) {}
      }

      const rec = new SpeechRecognitionClass();
      rec.continuous = false;
      rec.lang = "pt-BR";
      rec.interimResults = true;
      rec.maxAlternatives = 1;

      rec.onstart = () => {
        setIsListening(true);
        setIsRecordingMedia(false);
        setSpeechError("");
        setRealtimeSpeech("");
      };

      rec.onresult = (event: any) => {
        let interimTranscript = "";
        let finalTranscript = "";

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        if (interimTranscript) {
          setRealtimeSpeech(interimTranscript);
        }

        if (finalTranscript) {
          setLastSpeechDetected(finalTranscript);
          setRealtimeSpeech("");
          setIsListening(false);
          handleIncomingCommand(finalTranscript);
        }
      };

      rec.onerror = (event: any) => {
        setIsListening(false);
        setRealtimeSpeech("");
        console.warn("Native SpeechRecognition error:", event.error);
        if (event.error === "not-allowed" || event.error === "service-not-allowed") {
          setMicPermission("denied");
          setSpeechError("Reconhecimento nativo bloqueado. Comutando para gravação de áudio...");
          // Fallback to MediaRecorder on mobile
          startMediaRecording();
        } else if (event.error === "no-speech") {
          setSpeechError("Nenhuma fala detectada. Toque e fale claramente.");
        } else if (event.error === "network") {
          setSpeechError("Rede indisponível no reconhecimento nativo. Comutando para gravação de áudio...");
          startMediaRecording();
        } else {
          setSpeechError(`Aviso do microfone: ${event.error}`);
        }
      };

      rec.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = rec;
      rec.start();
    } catch (err: any) {
      console.warn("Native SpeechRecognition start failed, falling back to MediaRecorder:", err);
      startMediaRecording();
    }
  };

  // Unified voice listening toggle
  const toggleListening = async () => {
    if (!hasStarted) {
      setHasStarted(true);
    }

    if (isListening || isRecordingMedia) {
      if (isRecordingMedia) {
        stopMediaRecording();
      } else if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch (_) {}
      }
      setIsListening(false);
      return;
    }

    setSpeechError("");
    setRealtimeSpeech("");

    const SpeechRecognitionClass = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    // On mobile devices (iOS/Android), MediaRecorder + Gemini is the 100% reliable path:
    // It triggers the native browser microphone permission dialog instantly on tap without Web Speech drops or silent crashes.
    if (isMobile || preferredSpeechEngine === "gemini" || !SpeechRecognitionClass) {
      await startMediaRecording();
      return;
    }

    // On desktop, verify microphone permission and start native streaming Web Speech
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach(t => t.stop());
        setMicPermission("granted");
      }
      startListeningNative(SpeechRecognitionClass);
    } catch (err: any) {
      console.warn("Web Speech pre-check error, falling back to MediaRecorder:", err);
      if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
        setMicPermission("denied");
        setSpeechError("Permissão de microfone negada. Toque no cadeado do navegador para permitir o microfone.");
        setShowMicModal(true);
      } else {
        await startMediaRecording();
      }
    }
  };

  return (
    <div id="ecobot-root" className="min-h-screen bg-[#09090b] text-zinc-100 font-sans flex flex-col selection:bg-[#00FF55] selection:text-black relative overflow-x-hidden">
      
      {/* Background Image: Animais da Floresta Amazônica (Semi-transparente) */}
      {showBgImage && (
        <div 
          className="fixed inset-0 pointer-events-none z-0 overflow-hidden select-none transition-opacity duration-500" 
          aria-hidden="true"
          style={{ opacity: bgOpacity / 100 }}
        >
          <img
            src="/assets/images/amazon_wildlife.jpg"
            alt="Animais da Floresta Amazônica"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center scale-[1.02] filter contrast-110 saturate-125"
          />
          {/* Subtle gradient vignette to preserve contrast and HUD readability */}
          <div className="absolute inset-0 bg-radial from-black/20 via-[#09090b]/55 to-[#09090b]/90 pointer-events-none" />
        </div>
      )}

      {/* Waveform keyframe for active recording state */}
      <style>{`
        @keyframes customGrow {
          0%, 100% { height: 6px; }
          50% { height: 24px; }
        }
        .v-wave-1 { animation: customGrow 0.5s infinite ease-in-out; }
        .v-wave-2 { animation: customGrow 0.7s infinite ease-in-out 0.12s; }
        .v-wave-3 { animation: customGrow 0.4s infinite ease-in-out 0.24s; }
        .v-wave-4 { animation: customGrow 0.6s infinite ease-in-out 0.36s; }
        .text-glow-emerald {
          text-shadow: 0 0 12px rgba(0, 255, 85, 0.4);
        }
      `}</style>

      {/* Simplified, neat Navigation Row */}
      {!hidePanels && !isFullscreen && (
        <header id="ecobot-nav" className="bg-[#09090b]/85 backdrop-blur-md border-b border-zinc-900/60 py-4 px-6 sticky top-0 z-20">
          <div className="max-w-7xl mx-auto flex items-center justify-between relative">
            
            {/* Left side: Active status indicator */}
            <div className="flex items-center gap-2 select-none">
              <span className="w-2 h-2 rounded-full bg-[#00FF55] animate-pulse" />
              <span className="text-[10px] font-mono text-zinc-400 uppercase tracking-widest hidden sm:inline">assistente wit live</span>
              {showBgImage && (
                <span className="hidden lg:inline-flex items-center gap-1 text-[9px] font-mono font-bold bg-[#00FF55]/10 text-[#00FF55] border border-[#00FF55]/20 px-2 py-0.5 rounded-full">
                  Amazônia {bgOpacity}%
                </span>
              )}
            </div>

            {/* CENTER: Assistente Wit brand title */}
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 select-none">
              <span className="font-display font-black text-xl sm:text-2xl tracking-[0.15em] text-[#00FF55] text-glow-emerald uppercase leading-none whitespace-nowrap">
                Assistente Wit
              </span>
            </div>

            {/* Right Action buttons: Configurações & Reset tab swappers */}
            <div className="flex items-center gap-2">
              {/* Quick Amazon Background Toggle */}
              <button
                onClick={() => setShowBgImage(prev => !prev)}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[10px] font-mono font-bold tracking-tight uppercase transition-all duration-300 border cursor-pointer ${
                  showBgImage 
                    ? "border-[#00FF55]/40 bg-[#00FF55]/10 text-[#00FF55] hover:bg-[#00FF55]/20" 
                    : "border-zinc-800 bg-zinc-950/80 text-zinc-500 hover:text-zinc-300"
                }`}
                title={showBgImage ? "Ocultar fundo dos animais da Amazônia" : "Ativar fundo dos animais da Amazônia"}
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span className="hidden md:inline">{showBgImage ? `Fundo: ${bgOpacity}%` : "Fundo: OFF"}</span>
              </button>

              {activeTab === "chat" && (
                <button
                  onClick={toggleListening}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[10px] font-mono font-bold tracking-tight uppercase transition-all duration-300 border-2 cursor-pointer ${
                    isListening || isRecordingMedia
                      ? "bg-red-500 text-white border-black shadow-[0_0_10px_rgba(239,68,68,0.3)] animate-pulse"
                      : "bg-[#00FF55]/15 text-[#00FF55] border-[#00FF55]/30 hover:bg-[#00FF55] hover:text-black hover:border-black"
                  }`}
                  title={isListening || isRecordingMedia ? "Desativar microfone" : "Ativar microfone por voz"}
                >
                  {isListening || isRecordingMedia ? (
                    <>
                      <MicOff className="w-3.5 h-3.5" />
                      <span>{isRecordingMedia ? `Ouvindo (${recordingDuration}s)` : "Ouvindo..."}</span>
                    </>
                  ) : (
                    <>
                      <Mic className="w-3.5 h-3.5" />
                      <span>Falar</span>
                    </>
                  )}
                </button>
              )}

              <button
                onClick={() => setActiveTab(activeTab === "chat" ? "settings" : "chat")}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-[10px] font-mono font-bold tracking-tight uppercase transition-all duration-300 border border-zinc-800 bg-zinc-950 text-zinc-400 hover:text-[#00FF55] hover:border-[#00FF55]/40 cursor-pointer ${
                  activeTab === "settings" ? "text-[#00FF55] border-[#00FF55]/30 bg-[#00FF55]/5" : ""
                }`}
                title={activeTab === "chat" ? "Ir para Configurações" : "Ir para o Player"}
              >
                {activeTab === "chat" ? (
                  <>
                    <Settings className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Configurações</span>
                  </>
                ) : (
                  <>
                    <Tv className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Player</span>
                  </>
                )}
              </button>
            </div>

          </div>
        </header>
      )}

      {/* Main Area */}
      <main className={`flex-1 w-full max-w-7xl mx-auto ${isFullscreen ? "p-0" : "px-2 sm:px-6 py-3 sm:py-8"} flex flex-col justify-start transition-all duration-300 relative z-10`}>
        
        {/* VIEW 1: CHAT & PROJECTION (Simplified, dedicated single panel for interaction) */}
        {activeTab === "chat" && (
          <div className="space-y-6 animate-fade-in max-w-7xl mx-auto w-full transition-all duration-300">
            
            <div className="max-w-5xl mx-auto w-full flex flex-col gap-8">
              
              {/* Centered Video Stream Box Container */}
              <div className={`w-full relative ${isFullscreen ? "pt-0" : "pt-1 sm:pt-4 md:pt-6"}`}>
                
                {/* Main Video Box */}
                <div 
                  ref={videoContainerRef}
                  onTouchEnd={handleVideoTouch}
                  className={
                    isFullscreen
                      ? "fixed inset-0 z-50 w-screen h-[100dvh] bg-black m-0 p-0 overflow-hidden flex flex-col justify-center items-center"
                      : "bg-zinc-950 border-2 sm:border-3 border-black rounded-2xl sm:rounded-3xl relative h-[62vh] xs:h-[68vh] sm:h-[480px] md:h-[540px] flex flex-col justify-center items-center group shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] sm:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all duration-300"
                  }
                >
                  
                  {/* Inner overflow-hidden container to round off borders correctly */}
                  <div className={`absolute inset-0 ${isFullscreen ? "rounded-none" : "rounded-[14px] sm:rounded-[22px]"} overflow-hidden flex flex-col justify-center items-center`}>
                    
                    {/* Floating Layout Toggles Overlay (Always Accessible in Upper Right) */}
                    <div className="absolute top-3 right-3 z-30 flex items-center gap-1.5 bg-black/60 backdrop-blur-md p-1 sm:p-1.5 rounded-xl border border-zinc-800 shadow-xl">
                      {/* Fullscreen Button */}
                      <button
                        onClick={toggleFullscreen}
                        className={`bg-black/95 hover:bg-[#00FF55] hover:text-black hover:border-black border border-zinc-800 hover:scale-105 text-[#00FF55] text-[9px] font-mono font-black uppercase px-2.5 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 shadow-sm active:scale-95 ${
                          isFullscreen ? "bg-[#00FF55] text-black border-black font-extrabold" : ""
                        }`}
                        title={isFullscreen ? "Sair da Tela Inteira" : "Encaixar em Tela Inteira (Preencher Celular)"}
                      >
                        {isFullscreen ? <Minimize className="w-3.5 h-3.5" /> : <Maximize className="w-3.5 h-3.5" />}
                        <span>{isFullscreen ? "Sair" : "Tela Cheia"}</span>
                      </button>

                      {/* Video Fit Button */}
                      <button
                        onClick={() => setVideoFit(prev => prev === "contain" ? "cover" : "contain")}
                        className={`bg-black/95 hover:bg-[#00FF55] hover:text-black hover:border-black border border-zinc-800 hover:scale-105 text-[#00FF55] text-[9px] font-mono font-black uppercase px-2.5 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 shadow-sm active:scale-95 ${
                          videoFit === "cover" ? "border-[#00FF55]/60 bg-[#00FF55]/10" : ""
                        }`}
                        title={videoFit === "contain" ? "Preencher Tela Inteira (Ajuste Total)" : "Enquadramento Original Proporcional"}
                      >
                        <Tv className="w-3.5 h-3.5" />
                        <span>{videoFit === "cover" ? "Preenchido" : "Ajustado"}</span>
                      </button>

                      {/* Audio Button */}
                      <button
                        onClick={() => setVideoMuted(prev => !prev)}
                        className="bg-black/95 hover:bg-[#00FF55] hover:text-black hover:border-black border border-zinc-800 hover:scale-105 text-[#00FF55] text-[9px] font-mono font-black uppercase px-2 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1 shadow-sm active:scale-95"
                        title={videoMuted ? "Ativar Áudio" : "Silenciar Áudio"}
                      >
                        {videoMuted ? <VolumeX className="w-3.5 h-3.5 text-red-400" /> : <Volume2 className="w-3.5 h-3.5 text-[#00FF55]" />}
                      </button>

                      {!isFullscreen && (
                        <button
                          onClick={() => setHidePanels(prev => !prev)}
                          className={`bg-black/95 hover:bg-[#00FF55] hover:text-black hover:border-black border border-zinc-800 hover:scale-105 text-[#00FF55] text-[9px] font-mono font-black uppercase px-2 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1 shadow-sm ${hidePanels ? "bg-[#00FF55] text-black border-black" : ""}`}
                          title={hidePanels ? "Mostrar Painel, Chat e Opções de Controle" : "Ocultar Informações para Focar no Vídeo"}
                        >
                          {hidePanels ? <Eye className="w-3.2 h-3.2" /> : <EyeOff className="w-3.2 h-3.2" />}
                          <span className="hidden sm:inline">{hidePanels ? "Ver Painel" : "Ocultar"}</span>
                        </button>
                      )}
                    </div>

                    {/* Top Left Status Badge in Fullscreen */}
                    {isFullscreen && (
                      <div className="absolute top-3 left-3 z-30 flex items-center gap-2 bg-black/70 backdrop-blur-md px-3 py-1.5 rounded-xl border border-zinc-800 text-[10px] font-mono text-zinc-300 shadow-md">
                        <span className="w-2 h-2 rounded-full bg-[#00FF55] animate-pulse" />
                        <span className="font-bold text-white uppercase">{activeVideoSlot === "intro" ? "Apresentação (Intro)" : `Canal ${questions.findIndex(q => q.id === activeVideoSlot) + 1}`}</span>
                        {isMobile && (
                          <span className="text-[8px] bg-[#00FF55]/20 text-[#00FF55] px-1.5 py-0.5 rounded font-extrabold uppercase">
                            Mobile
                          </span>
                        )}
                      </div>
                    )}

                    {!hasStarted ? (
                      <div className="absolute inset-0 bg-zinc-950 flex flex-col items-center justify-center p-8 text-center z-40 animate-fade-in text-zinc-300">
                        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,255,85,0.15)_0%,transparent_70%)] opacity-70 pointer-events-none" />
                        
                        <div className="relative mb-6">
                          <div className="w-20 h-20 rounded-full bg-zinc-900 border-2 border-[#00FF55] flex items-center justify-center text-[#00FF55] shadow-[0_0_20px_rgba(0,255,85,0.25)] animate-pulse">
                            <Sparkles className="w-8 h-8 text-[#00FF55]" />
                          </div>
                        </div>

                        <div className="space-y-3 max-w-sm">
                          <h4 className="font-display font-black text-lg md:text-xl text-white uppercase tracking-wider leading-tight">
                            Bem-vindo ao Assistente Wit
                          </h4>
                          <p className="text-xs text-zinc-400 font-mono">
                            {isMobile ? "Modo Mobile Otimizado: vídeos preenchem a tela inteira." : "Experiência interativa com vídeos locais e reconhecimento por voz."}
                          </p>
                        </div>

                        <button
                          onClick={() => {
                            setVideoMuted(false);
                            triggerVideoSlot("intro");
                          }}
                          className="mt-8 px-6 py-3.5 bg-[#00FF55] text-black font-display font-black text-xs uppercase tracking-widest rounded-xl border-3 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:translate-y-[1px] hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-y-[3px] active:shadow-none hover:bg-white hover:text-black transition-all cursor-pointer select-none"
                        >
                          Iniciar Experimentação
                        </button>
                      </div>
                    ) : getActiveVideoUrl() ? (
                      <div className="absolute inset-0 bg-black flex items-center justify-center">
                        <video
                          key={activeVideoSlot}
                          ref={videoRef}
                          src={getActiveVideoUrl()}
                          className={`w-full h-full ${videoFit === "contain" ? "object-contain" : "object-cover"} ${videoFinished ? "blur-[2.5px]" : ""} transition-all duration-500`}
                          autoPlay
                          muted={videoMuted}
                          playsInline
                          webkit-playsinline="true"
                          onEnded={() => {
                            setVideoFinished(true);
                            setShowReplayPrompt(true);
                            setViewedSlots((prev) => {
                              if (prev.includes(activeVideoSlot)) return prev;
                              return [...prev, activeVideoSlot];
                            });
                            // Return / exit full screen when video ends to show available triggers
                            exitFullscreenAuto();
                          }}
                          onError={() => {
                            setVideoPlayError("Não foi possível reproduzir este arquivo de vídeo local.");
                          }}
                        />

                        {/* END OF VIDEO: SPINNER OR THANK YOU OVERLAYS */}
                        {videoFinished && (
                          <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] flex flex-col items-center justify-center p-6 z-20 animate-fade-in select-none">
                            {/* QUESTIONS (PERGUNTAS / GATILHOS) ON SCREEN */}
                            <div className="bg-transparent border-0 shadow-none max-w-2xl w-full flex flex-col items-center justify-center animate-scale-up">
                              
                              <div className="flex flex-col items-center justify-center text-center gap-2 mb-4">
                                <div className="flex items-center gap-2 bg-[#00FF55] text-black px-3.5 py-1 rounded-full font-mono text-[9px] font-black uppercase tracking-wider shadow-sm">
                                  <span className="w-1.5 h-1.5 rounded-full bg-black animate-ping" />
                                  <span>Vídeo Concluído — Escolha um Gatilho</span>
                                </div>
                                <p className="text-[11px] font-mono text-zinc-300">
                                  Fale no microfone ou toque em uma das perguntas para iniciar em tela cheia:
                                </p>
                              </div>

                              <div className="flex flex-col gap-3.5 w-full max-h-[260px] overflow-y-auto pr-1 items-center justify-center">
                                {questions.map((q, idx) => {
                                  const isViewed = viewedSlots.includes(q.id);
                                  return (
                                    <button
                                      key={q.id}
                                      onClick={() => {
                                        triggerVideoSlot(q.id);
                                      }}
                                      disabled={!q.videoUrl}
                                      className="relative bg-black/75 hover:bg-black border border-zinc-800 hover:border-[#00FF55] px-5 py-2.5 rounded-xl text-center transition-all duration-300 cursor-pointer outline-none focus:outline-none flex flex-col items-center justify-center select-none shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:scale-105 active:scale-95 group"
                                    >
                                      {/* Phrase with deep drop shadow for perfect readability on video overlays */}
                                      <p className={`font-display font-black text-sm md:text-base uppercase tracking-widest transition-all ${
                                        isViewed
                                          ? "text-zinc-400 group-hover:text-white"
                                          : "text-[#00FF55] group-hover:text-white"
                                      } [text-shadow:0_2px_10px_rgba(0,0,0,1)]`}>
                                        🎤 "{q.phrase}"
                                      </p>
                                    </button>
                                  );
                                })}
                              </div>

                              {/* Action buttons: Rever Vídeo & Iniciar do Zero */}
                              <div className="flex flex-wrap items-center justify-center gap-4 mt-6 w-full">
                                <button
                                  onClick={() => {
                                    setVideoFinished(false);
                                    enterFullscreenAuto();
                                    if (videoRef.current) {
                                      videoRef.current.currentTime = 0;
                                      const playPromise = videoRef.current.play();
                                      if (playPromise !== undefined) {
                                        playPromise.catch(err => console.warn("Failed to play: ", err));
                                      }
                                    }
                                  }}
                                  className="flex items-center gap-2 px-5 py-2.5 bg-zinc-950/95 border-2 border-black hover:border-zinc-700 text-white font-mono text-[10px] font-bold uppercase rounded-xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 active:translate-y-0.5 active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] transition-all duration-200 cursor-pointer"
                                >
                                  <RotateCcw className="w-3.5 h-3.5 text-zinc-400" />
                                  <span>Rever Vídeo</span>
                                </button>

                                <button
                                  onClick={() => {
                                    setViewedSlots([]);
                                    triggerVideoSlot("intro");
                                  }}
                                  className="flex items-center gap-2 px-5 py-2.5 bg-[#00FF55] hover:bg-[#00FF55]/90 text-black border-2 border-black font-mono text-[10px] font-black uppercase rounded-xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 active:translate-y-0.5 active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] transition-all duration-200 cursor-pointer"
                                >
                                  <Play className="w-3.5 h-3.5 fill-black" />
                                  <span>Iniciar do Zero</span>
                                </button>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Video Controls bar inside iframe overlay */}
                        {!isIntroSpecialVideo && (
                          <div className="absolute bottom-3 left-3 z-10 bg-black/85 border border-[#00FF55]/40 text-[#00FF55] text-[10px] font-mono px-2.5 py-1 rounded flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#00FF55] animate-pulse" />
                            <span>MÍDIA LOCAL ATIVA</span>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="p-8 text-center max-w-sm flex flex-col items-center gap-4 bg-white/5 backdrop-blur-md text-zinc-300">
                        <div className="w-16 h-16 rounded-full bg-zinc-900 border-2 border-[#00FF55] flex items-center justify-center shadow-[0_0_15px_rgba(0,255,85,0.25)] animate-pulse">
                          <Video className="w-7 h-7 text-[#00FF55]" />
                        </div>
                        <div className="space-y-2">
                          <h4 className="font-bold text-sm text-white uppercase tracking-wider">Nenhum Vídeo Carregado nesta Rota</h4>
                          <p className="text-xs text-zinc-400 leading-relaxed">
                            Vá no menu de <span className="text-[#00FF55] font-bold cursor-pointer underline" onClick={() => setActiveTab("settings")}>Configurações</span> para carregar os seus vídeos locais e sintonizar os gatilhos corretamente.
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Sub-system Alerts inside screen */}
                    {videoPlayError && (
                      <div className="absolute inset-0 bg-white/95 flex flex-col items-center justify-center p-5 text-center z-10 border-2 border-red-500">
                        <AlertTriangle className="w-8 h-8 text-red-500 mb-1" />
                        <span className="text-[10px] font-mono font-bold text-red-600 block">FALHA DE CARREGAMENTO</span>
                        <p className="text-[11px] text-zinc-600 max-w-xs mt-1 leading-normal font-sans">
                          {videoPlayError}
                        </p>
                        <button
                          onClick={() => setVideoPlayError("")}
                          className="mt-3 px-3 py-1 bg-black text-[#00FF55] hover:bg-zinc-800 text-[10px] font-mono font-bold rounded-lg transition-all border border-black cursor-pointer"
                        >
                          IGNORAR
                        </button>
                      </div>
                    )}
                    
                    {/* Active Route Slot Indicators on the bottom right corner */}
                    <div className="absolute bottom-3 right-3 z-10 flex flex-wrap gap-1 bg-zinc-950/90 backdrop-blur-md p-1 rounded-lg border border-zinc-800 text-[10px] font-mono shadow-sm max-w-[180px]">
                      <button
                        onClick={() => triggerVideoSlot("intro")}
                        disabled={!introUrl}
                        className={`px-2 py-0.5 rounded font-bold transition-all disabled:opacity-30 disabled:cursor-not-allowed ${activeVideoSlot === "intro" ? "bg-[#00FF55] text-black border border-black" : "text-zinc-400 hover:text-white"}`}
                        title="Ir para o vídeo inicial em tela cheia"
                      >
                        Intro
                      </button>
                      {questions.map((q, idx) => (
                        <button
                          key={q.id}
                          onClick={() => triggerVideoSlot(q.id)}
                          disabled={!q.videoUrl}
                          className={`px-2 py-0.5 rounded font-bold transition-all disabled:opacity-30 disabled:cursor-not-allowed ${activeVideoSlot === q.id ? "bg-[#00FF55] text-black border border-black" : "text-zinc-400 hover:text-white"}`}
                          title={`Canal da Pergunta ${idx + 1} em tela cheia`}
                        >
                          Q{idx + 1}
                        </button>
                      ))}
                    </div>

                    {/* Floating Voice & Quick Control Dock when in Fullscreen */}
                    {isFullscreen && (
                      <div className="absolute bottom-5 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2.5 bg-black/85 backdrop-blur-md px-4 py-2 rounded-full border border-zinc-800 shadow-[0_4px_30px_rgba(0,0,0,0.9)] max-w-[95vw]">
                        <button
                          onClick={toggleListening}
                          className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full font-mono text-[10px] font-black uppercase border transition-all cursor-pointer ${
                            isListening
                              ? "bg-red-500 text-white border-white shadow-[0_0_12px_rgba(239,68,68,0.6)] animate-pulse"
                              : "bg-[#00FF55] text-black border-black hover:bg-white active:scale-95"
                          }`}
                        >
                          {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                          <span>{isListening ? "Ouvindo..." : "Falar"}</span>
                        </button>
                        
                        <div className="h-4 w-px bg-zinc-800" />

                        <button
                          onClick={() => {
                            setVideoFinished(false);
                            if (videoRef.current) {
                              videoRef.current.currentTime = 0;
                              videoRef.current.play().catch(e => console.warn(e));
                            }
                          }}
                          className="text-zinc-400 hover:text-[#00FF55] p-1.5 rounded transition-colors"
                          title="Rever Vídeo"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => setVideoFit(prev => prev === "cover" ? "contain" : "cover")}
                          className="text-zinc-400 hover:text-[#00FF55] text-[9px] font-mono px-2 py-1 rounded border border-zinc-800"
                          title="Alternar Encaixe de Vídeo"
                        >
                          {videoFit === "cover" ? "Preenchido" : "Original"}
                        </button>

                        <div className="h-4 w-px bg-zinc-800" />

                        <button
                          onClick={toggleFullscreen}
                          className="flex items-center gap-1 text-zinc-300 hover:text-white text-[9px] font-mono font-bold bg-zinc-900 px-2 py-1 rounded border border-zinc-800"
                          title="Sair da Tela Inteira"
                        >
                          <Minimize className="w-3 h-3 text-[#00FF55]" />
                          <span>Sair</span>
                        </button>
                      </div>
                    )}

                  </div>

                </div>

                {/* Mobile Quick Bar for Voice, Fullscreen and Fit */}
                {isMobile && !isFullscreen && (
                  <div className="mt-2.5 flex flex-col gap-2 bg-zinc-950/95 backdrop-blur-md border border-zinc-800 rounded-xl p-2.5 text-[10px] font-mono text-zinc-300 shadow-md">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5 truncate">
                        <Smartphone className="w-3.5 h-3.5 text-[#00FF55] shrink-0" />
                        <span className="truncate">Modo Mobile: <strong className="text-[#00FF55]">{videoFit === "cover" ? "Preenchendo" : "Ajustado"}</strong></span>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => setVideoFit(prev => prev === "cover" ? "contain" : "cover")}
                          className="text-zinc-400 hover:text-white px-2 py-1 rounded border border-zinc-800 hover:border-zinc-700 bg-zinc-900 font-bold active:scale-95 transition-all text-[9px]"
                        >
                          {videoFit === "cover" ? "Ajustar" : "Preencher"}
                        </button>
                        <button
                          type="button"
                          onClick={toggleFullscreen}
                          className="flex items-center gap-1 text-black font-black bg-[#00FF55] hover:bg-[#00FF55]/90 px-2.5 py-1 rounded border border-black cursor-pointer shadow-sm active:scale-95 transition-all text-[9px]"
                        >
                          <Maximize className="w-3 h-3" />
                          <span>Tela Cheia</span>
                        </button>
                      </div>
                    </div>

                    {/* Dedicated Primary Mobile Voice Button */}
                    <button
                      type="button"
                      onClick={toggleListening}
                      className={`w-full py-2.5 px-3 rounded-lg border-2 font-mono text-[11px] font-black uppercase flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm active:scale-98 ${
                        isListening || isRecordingMedia
                          ? "bg-red-500 text-white border-white animate-pulse shadow-[0_0_12px_rgba(239,68,68,0.6)]"
                          : "bg-[#00FF55] text-black border-black hover:bg-[#00FF55]/90 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                      }`}
                    >
                      {isListening || isRecordingMedia ? (
                        <>
                          <MicOff className="w-4 h-4" />
                          <span>Ouvindo no Celular... ({recordingDuration}s) Toque p/ Parar</span>
                        </>
                      ) : isTranscribing ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin text-black" />
                          <span>Transcrevendo Fala com IA...</span>
                        </>
                      ) : (
                        <>
                          <Mic className="w-4 h-4" />
                          <span>Toque Aqui para Falar (Microfone)</span>
                        </>
                      )}
                    </button>
                  </div>
                )}

              </div>

              {/* Gatilhos Disponíveis (Interactive Triggers Panel - Displayed clearly after video finishes or for quick access) */}
              <div className={`bg-zinc-950/85 backdrop-blur-md border-2 sm:border-3 border-black rounded-2xl sm:rounded-3xl p-5 sm:p-6 shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] flex flex-col gap-4 text-left transition-all duration-300 ${
                videoFinished ? "ring-2 ring-[#00FF55] shadow-[0_0_20px_rgba(0,255,85,0.25)]" : ""
              }`}>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800/80 pb-3">
                  <div className="flex items-center gap-2.5">
                    <span className={`w-2.5 h-2.5 rounded-full ${videoFinished ? "bg-[#00FF55] animate-ping" : "bg-[#00FF55]"}`} />
                    <h3 className="font-display font-black text-xs sm:text-sm uppercase tracking-wider text-white">
                      Gatilhos de Pergunta Disponíveis
                    </h3>
                    <span className="text-[9px] font-mono bg-zinc-900 text-[#00FF55] px-2 py-0.5 rounded font-extrabold border border-zinc-800 uppercase">
                      {videoFinished ? "Aguardando Próxima Pergunta" : "Fale ou Toque a Qualquer Momento"}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-zinc-400">
                    Toque em um gatilho ou use o microfone para iniciar em tela cheia
                  </span>
                </div>

                {/* Grid of Triggers / Gatilhos */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {questions.map((q, idx) => {
                    const isViewed = viewedSlots.includes(q.id);
                    const isActive = activeVideoSlot === q.id && !videoFinished;
                    return (
                      <button
                        key={q.id}
                        type="button"
                        onClick={() => triggerVideoSlot(q.id)}
                        disabled={!q.videoUrl}
                        className={`group relative flex items-center justify-between gap-3 p-3.5 rounded-xl border-2 transition-all cursor-pointer text-left ${
                          isActive
                            ? "bg-[#00FF55]/15 border-[#00FF55] text-white shadow-[3px_3px_0px_0px_rgba(0,255,85,0.4)]"
                            : videoFinished && !isViewed
                            ? "bg-zinc-900/90 hover:bg-zinc-850 border-[#00FF55]/70 hover:border-[#00FF55] text-white shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:translate-y-[-1px]"
                            : "bg-zinc-900/60 hover:bg-zinc-850 border-zinc-800 hover:border-zinc-700 text-zinc-300 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                        } disabled:opacity-30 disabled:pointer-events-none active:scale-98`}
                      >
                        <div className="flex items-center gap-2.5 truncate">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border ${
                            isActive ? "bg-[#00FF55] text-black border-black" : "bg-black text-[#00FF55] border-zinc-800"
                          }`}>
                            <Mic className="w-4 h-4" />
                          </div>
                          <div className="truncate">
                            <div className="text-[9px] font-mono text-zinc-400 font-bold uppercase">
                              Canal {idx + 1} {isViewed && "• Já Visto"}
                            </div>
                            <div className="font-display font-black text-xs sm:text-sm text-[#00FF55] group-hover:text-white truncate">
                              "{q.phrase}"
                            </div>
                          </div>
                        </div>

                        <span className="shrink-0 text-[9px] font-mono font-bold uppercase px-2 py-1 rounded bg-black border border-zinc-800 text-zinc-300 flex items-center gap-1 group-hover:border-[#00FF55] group-hover:text-[#00FF55]">
                          <Play className="w-2.5 h-2.5 fill-current text-[#00FF55]" />
                          <span>Tela Cheia</span>
                        </span>
                      </button>
                    );
                  })}

                  {/* Intro restart button in triggers panel */}
                  <button
                    type="button"
                    onClick={() => triggerVideoSlot("intro")}
                    disabled={!introUrl}
                    className="group relative flex items-center justify-between gap-3 p-3.5 rounded-xl border-2 bg-zinc-900/60 hover:bg-zinc-850 border-zinc-800 hover:border-zinc-700 text-zinc-300 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] disabled:opacity-30 disabled:pointer-events-none cursor-pointer active:scale-98"
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border bg-black text-zinc-400 border-zinc-800 group-hover:text-white">
                        <RotateCcw className="w-4 h-4" />
                      </div>
                      <div className="truncate">
                        <div className="text-[9px] font-mono text-zinc-400 font-bold uppercase">
                          Apresentação
                        </div>
                        <div className="font-display font-black text-xs sm:text-sm text-zinc-200 group-hover:text-white truncate">
                          "Introdução"
                        </div>
                      </div>
                    </div>
                    <span className="shrink-0 text-[9px] font-mono font-bold uppercase px-2 py-1 rounded bg-black border border-zinc-800 text-zinc-400 flex items-center gap-1 group-hover:text-white">
                      <Play className="w-2.5 h-2.5 fill-current text-zinc-400" />
                      <span>Tela Cheia</span>
                    </span>
                  </button>
                </div>
              </div>

              {/* Seamless Voice Chat & Manual Companion Box - Centered at the Bottom */}
              <div className="bg-zinc-900/40 backdrop-blur-md border-3 border-black rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] text-left flex flex-col md:flex-row gap-6 items-stretch">
                
                {/* Speaking Control Badge */}
                <div className="bg-zinc-950/60 border-2 border-zinc-800/80 rounded-2xl p-6 flex flex-col items-center justify-center text-center gap-4 min-w-[220px] shrink-0">
                  
                  {/* Large Speak Button */}
                  <button
                    type="button"
                    onClick={toggleListening}
                    className={`w-16 h-16 rounded-full flex items-center justify-center transition-all border-3 border-black cursor-pointer ${
                      isListening || isRecordingMedia
                        ? "bg-red-500 text-white shadow-[0_0_18px_rgba(239,68,68,0.6)] animate-pulse"
                        : "bg-[#00FF55] text-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:translate-y-[1px] hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-y-[3px] active:shadow-none"
                    }`}
                    title={isListening || isRecordingMedia ? "Desativar escuta de voz" : "Ativar microfone para ouvir"}
                  >
                    {isListening || isRecordingMedia ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                  </button>

                  <div className="space-y-1 w-full">
                    {isTranscribing ? (
                      <div className="flex flex-col items-center gap-1.5 py-1">
                        <RefreshCw className="w-4 h-4 text-[#00FF55] animate-spin" />
                        <span className="text-[10px] font-mono font-bold text-[#00FF55] uppercase animate-pulse">
                          Transcrevendo áudio...
                        </span>
                      </div>
                    ) : isListening || isRecordingMedia ? (
                      <div className="space-y-2">
                        <span className="text-[10px] font-mono font-bold text-red-500 uppercase tracking-wider block animate-pulse">
                          {isRecordingMedia ? `GRAVANDO VOZ (${recordingDuration}s)` : "ESCUTA ATIVA..."}
                        </span>
                        
                        {/* Interactive dynamic audio lightbars linked to live audioLevel */}
                        <div className="flex items-end justify-center gap-1.5 h-6 pt-1">
                          <div 
                            className="w-1.5 bg-red-400 rounded-full transition-all duration-75"
                            style={{ height: `${Math.max(6, Math.min(24, Math.round(audioLevel * 0.25)))}px` }}
                          />
                          <div 
                            className="w-1.5 bg-[#00FF55] rounded-full border border-black transition-all duration-75"
                            style={{ height: `${Math.max(10, Math.min(24, Math.round(audioLevel * 0.4)))}px` }}
                          />
                          <div 
                            className="w-1.5 bg-[#00FF55] rounded-full border border-black transition-all duration-75"
                            style={{ height: `${Math.max(8, Math.min(24, Math.round(audioLevel * 0.35)))}px` }}
                          />
                          <div 
                            className="w-1.5 bg-red-400 rounded-full transition-all duration-75"
                            style={{ height: `${Math.max(6, Math.min(24, Math.round(audioLevel * 0.2)))}px` }}
                          />
                        </div>
                        <span className="text-[9px] font-mono text-zinc-400 block">
                          Toque p/ enviar comando
                        </span>
                      </div>
                    ) : isAnalyzing ? (
                      <span className="text-xs font-bold text-zinc-300 animate-pulse block">
                        Analisando frequências...
                      </span>
                    ) : (
                      <div className="flex flex-col items-center gap-1.5">
                        <span className="text-xs font-bold text-zinc-400 block">
                          Fale para interagir
                        </span>
                        <div className="flex items-center gap-1.5 text-xs font-mono bg-zinc-900 border border-zinc-800 px-2 py-0.5 rounded-md">
                          <span className={`w-2 h-2 rounded-full border border-black/25 ${micPermission === "granted" ? "bg-[#00FF55]" : micPermission === "denied" ? "bg-red-500" : "bg-amber-400"}`} />
                          <span className="font-bold text-[9px] text-zinc-400">
                            {micPermission === "granted" ? "MICROFONE PRONTO" : micPermission === "denied" ? "MICROFONE BLOQUEADO" : "CLIQUE P/ FALAR"}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>

                  {speechError && (
                    <div className="w-full p-2.5 bg-red-950/60 border border-red-800/80 rounded-xl text-[10px] text-red-300 font-mono space-y-1.5 text-center">
                      <div className="flex items-center justify-center gap-1 text-red-400 font-bold">
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                        <span>Aviso de Microfone</span>
                      </div>
                      <p className="leading-tight text-[9px]">{speechError}</p>
                      <button
                        type="button"
                        onClick={requestMicrophonePermission}
                        className="w-full mt-1 py-1 px-2 bg-red-600 hover:bg-red-500 text-white rounded font-bold text-[9px] uppercase tracking-wide cursor-pointer transition-colors shadow-sm"
                      >
                        Habilitar Microfone no Celular
                      </button>
                    </div>
                  )}

                </div>

                {/* Speech transcript & manual fallback */}
                <div className="flex-1 flex flex-col justify-between gap-4">
                  
                  {/* Real-time Subtitles / Message Box */}
                  <div className="bg-zinc-950/60 border-2 border-zinc-800/80 rounded-2xl p-5 text-xs flex-1 flex flex-col justify-center">
                    <div>
                      <span className="text-[9px] text-zinc-500 font-mono block uppercase font-bold tracking-wider mb-2">
                        {isListening ? "Transcrição em Tempo Real:" : "Você perguntou:"}
                      </span>
                      <p className={`font-display font-extrabold italic text-sm mt-0.5 transition-all ${isListening ? "text-[#00FF55] bg-[#00FF55]/10 border border-dashed border-[#00FF55]/30 px-3 py-2 rounded animate-pulse" : "text-zinc-100"}`}>
                        {isListening 
                          ? (realtimeSpeech ? `"${realtimeSpeech}"` : "Ouvindo atentamente... fale algo") 
                          : (lastSpeechDetected ? `"${lastSpeechDetected}"` : "Aguardando transmissão de voz...")
                        }
                      </p>
                    </div>
                  </div>

                  {/* Backup input bar */}
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      handleIncomingCommand(inputText);
                    }}
                    className="relative"
                  >
                    <input
                      type="text"
                      className="w-full bg-zinc-950 border-2 border-zinc-800 focus:ring-0 focus:border-[#00FF55] rounded-xl pl-3.5 pr-11 py-2.5 text-xs text-zinc-150 placeholder-zinc-500 font-mono shadow-[2px_2px_0px_0px_rgba(0,0,0,0.5)] focus:outline-none transition-all"
                      placeholder="Escreva a pergunta correspondente aqui..."
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      disabled={isAnalyzing}
                    />
                    <button
                      type="submit"
                      disabled={isAnalyzing || !inputText.trim()}
                      className="absolute right-1.5 top-1.5 w-7.5 h-7.5 rounded bg-[#00FF55] border border-black hover:bg-black hover:text-[#00FF55] transition-all flex items-center justify-center cursor-pointer shadow-sm"
                    >
                      <Send className="w-3 h-3" />
                    </button>
                  </form>

                </div>

              </div>

            </div>

            {/* Minimalist Configuration Action Bar */}
            {!hidePanels && (
              <div className="bg-zinc-900/20 backdrop-blur-md rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between border border-zinc-800/80 gap-4 text-left max-w-5xl mx-auto w-full">
                <div className="flex items-center gap-3">
                  <div className="bg-zinc-950 border border-zinc-800 text-[10px] h-6 px-2.5 rounded-lg font-mono text-zinc-400 font-bold flex items-center shrink-0">
                    SISTEMA ATIVO
                  </div>
                  <p className="text-[11px] text-zinc-400 leading-none font-mono">
                    Gatilhos de voz sintonizados e prontos para interação.
                  </p>
                </div>

                <button
                  onClick={() => setActiveTab("settings")}
                  className="bg-zinc-950 hover:bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-2 font-mono text-[10px] font-bold text-[#00FF55] hover:border-[#00FF55]/35 transition-all cursor-pointer shadow-sm flex items-center gap-2 uppercase tracking-wider"
                >
                  <Settings className="w-3.5 h-3.5" />
                  <span>Configurar Canais</span>
                </button>
              </div>
            )}

          </div>
        )}

        {/* VIEW 2: AJUSTES DA CENTRAL (Optimized, Simplified and Professional Settings Tab) */}
        {activeTab === "settings" && (
          <div className="space-y-6 animate-fade-in">
            
            <div className="bg-zinc-950 border-3 border-black rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] text-left flex flex-col gap-6 text-zinc-100">
              
              {/* Header section with clean typography & solid controls */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-900 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] font-mono font-bold bg-[#00FF55] text-black border border-black px-2 py-0.5 rounded uppercase">
                      Painel do Operador
                    </span>
                    <span className="text-[9px] font-mono font-bold bg-zinc-900 text-zinc-400 border border-zinc-800 px-2 py-0.5 rounded uppercase">
                      v2.1
                    </span>
                  </div>
                  <h2 className="text-sm font-display font-black text-white uppercase tracking-wider mt-1.5">
                    Configuração de Canais e Voz
                  </h2>
                  <p className="text-[11px] text-zinc-400 mt-0.5 font-mono">
                    Gerencie a transmissão e associe comandos falados aos canais de vídeo.
                  </p>
                </div>
                
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={resetAllTriggers}
                    className="flex items-center gap-1.5 bg-zinc-900 hover:bg-zinc-850 text-zinc-400 hover:text-zinc-200 text-[10px] font-bold px-3 py-2 rounded-lg border border-zinc-800 transition-all cursor-pointer shadow-sm font-mono uppercase"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Redefinir</span>
                  </button>

                  <button
                    onClick={() => setActiveTab("chat")}
                    className="flex items-center gap-1.5 bg-[#00FF55] text-black hover:bg-[#00FF55]/85 text-[10px] font-black px-4 py-2 rounded-lg transition-all cursor-pointer uppercase font-mono tracking-wider shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]"
                  >
                    <span>Concluído</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* 12-Column Grid Layout for Settings Panel */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

                {/* Left Side: System & Intro Flow (Col Span: 4) */}
                <div className="lg:col-span-4 space-y-5">
                  
                  {/* Card 1: Intro Video config */}
                  <div className="bg-zinc-900/40 border border-zinc-900 rounded-2xl p-4 flex flex-col justify-between gap-4 text-left">
                    <div>
                      <div className="flex justify-between items-center border-b border-zinc-900 pb-2">
                        <span className="text-[11px] font-mono font-bold text-zinc-200 uppercase tracking-wide flex items-center gap-1.5">
                          <Video className="w-3.5 h-3.5 text-[#00FF55]" />
                          Vídeo de Apresentação (Intro)
                        </span>
                        {introUrl && (
                          <span className="text-[8px] bg-[#00FF55]/10 text-[#00FF55] px-1.5 py-0.5 rounded font-extrabold font-mono border border-[#00FF55]/20">
                            ATIVO
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-zinc-500 leading-normal mt-2 font-mono">
                        Vídeo padrão reproduzido na inicialização ou ao recomeçar a visita guiada.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <label className="border border-dashed border-zinc-800 hover:border-[#00FF55]/50 bg-zinc-950/80 rounded-xl p-4 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-1 min-h-[90px]">
                        <input
                          type="file"
                          accept="video/*"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleFileChange("intro", file);
                          }}
                          className="hidden"
                        />
                        <Upload className="w-4 h-4 text-zinc-650 mb-0.5" />
                        {introName ? (
                          <span className="text-[#00FF55] font-bold max-w-full truncate block px-1 text-[10px] font-mono">
                            {introName}
                          </span>
                        ) : (
                          <span className="text-zinc-500 font-mono text-[10px]">Importar arquivo (.mp4)</span>
                        )}
                      </label>

                      <button
                        type="button"
                        onClick={() => {
                          if (introUrl) {
                            triggerVideoSlot("intro");
                            setActiveTab("chat");
                          }
                        }}
                        disabled={!introUrl}
                        className="w-full flex items-center justify-center gap-1 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-850 active:bg-zinc-950 border border-zinc-800 rounded-lg text-zinc-300 hover:text-[#00FF55] disabled:opacity-35 disabled:pointer-events-none transition-all cursor-pointer font-bold font-mono text-[9px] uppercase shadow-sm"
                      >
                        Visualizar Intro em Tela Cheia
                      </button>
                    </div>
                  </div>

                  {/* Card 2: Plano de Fundo - Animais da Floresta Amazônica */}
                  <div className="bg-zinc-900/40 border border-zinc-900 rounded-2xl p-4 flex flex-col justify-between gap-4 text-left">
                    <div>
                      <div className="flex justify-between items-center border-b border-zinc-900 pb-2">
                        <span className="text-[11px] font-mono font-bold text-zinc-200 uppercase tracking-wide flex items-center gap-1.5">
                          <ImageIcon className="w-3.5 h-3.5 text-[#00FF55]" />
                          Fundo Floresta Amazônica
                        </span>
                        <span className={`text-[8px] px-1.5 py-0.5 rounded font-extrabold font-mono border ${
                          showBgImage 
                            ? "bg-[#00FF55]/10 text-[#00FF55] border-[#00FF55]/20" 
                            : "bg-zinc-800 text-zinc-400 border-zinc-700"
                        }`}>
                          {showBgImage ? "ATIVO" : "INATIVO"}
                        </span>
                      </div>
                      <p className="text-[10px] text-zinc-500 leading-normal mt-2 font-mono">
                        Papel de parede com animais da fauna amazônica (onça-pintada, araras, tucanos, bicho-preguiça, sapos-pontas-de-flecha).
                      </p>
                    </div>

                    {/* Preview Image with overlay effect */}
                    <div className="relative rounded-xl overflow-hidden border border-zinc-800 h-28 group">
                      <img 
                        src="/assets/images/amazon_wildlife.jpg" 
                        alt="Miniatura Animais da Amazônia"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-black/40 flex items-end p-2 justify-between">
                        <span className="text-[9px] font-mono font-bold text-white bg-black/70 px-1.5 py-0.5 rounded backdrop-blur-sm">
                          Fauna Amazônica
                        </span>
                        <span className="text-[9px] font-mono font-bold text-[#00FF55] bg-black/70 px-1.5 py-0.5 rounded backdrop-blur-sm">
                          {bgOpacity}% Opacidade
                        </span>
                      </div>
                    </div>

                    {/* Controls */}
                    <div className="space-y-3 pt-1">
                      {/* Toggle Button */}
                      <button
                        type="button"
                        onClick={() => setShowBgImage(prev => !prev)}
                        className={`w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg font-mono font-bold text-[10px] uppercase transition-all cursor-pointer border ${
                          showBgImage
                            ? "bg-[#00FF55]/15 text-[#00FF55] border-[#00FF55]/30 hover:bg-[#00FF55]/25"
                            : "bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-white"
                        }`}
                      >
                        <ImageIcon className="w-3.5 h-3.5" />
                        <span>{showBgImage ? "Ocultar Fundo" : "Ativar Fundo"}</span>
                      </button>

                      {/* Opacity Range Slider */}
                      {showBgImage && (
                        <div className="space-y-1.5 bg-zinc-950/60 p-2.5 rounded-xl border border-zinc-900">
                          <div className="flex justify-between items-center text-[10px] font-mono">
                            <span className="text-zinc-400">Transparência / Opacidade:</span>
                            <span className="text-[#00FF55] font-bold">{bgOpacity}%</span>
                          </div>
                          <input
                            type="range"
                            min="10"
                            max="85"
                            step="5"
                            value={bgOpacity}
                            onChange={(e) => setBgOpacity(Number(e.target.value))}
                            className="w-full accent-[#00FF55] cursor-pointer"
                          />
                          <div className="flex justify-between text-[8px] font-mono text-zinc-600">
                            <span>Mais Transparente (10%)</span>
                            <span>Recomendado (35%)</span>
                            <span>Mais Vívido (85%)</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Card 3: Otimização Mobile & Tela Inteira */}
                  <div className="bg-zinc-900/40 border border-zinc-900 rounded-2xl p-4 flex flex-col justify-between gap-4 text-left">
                    <div>
                      <div className="flex justify-between items-center border-b border-zinc-900 pb-2">
                        <span className="text-[11px] font-mono font-bold text-zinc-200 uppercase tracking-wide flex items-center gap-1.5">
                          <Smartphone className="w-3.5 h-3.5 text-[#00FF55]" />
                          Modo Mobile & Tela Inteira
                        </span>
                        <span className={`text-[8px] px-1.5 py-0.5 rounded font-extrabold font-mono border ${
                          videoFit === "cover"
                            ? "bg-[#00FF55]/10 text-[#00FF55] border-[#00FF55]/20"
                            : "bg-zinc-800 text-zinc-400 border-zinc-700"
                        }`}>
                          {videoFit === "cover" ? "PREENCHER TELA" : "ORIGINAL"}
                        </span>
                      </div>
                      <p className="text-[10px] text-zinc-500 leading-normal mt-2 font-mono">
                        Ajuste para celulares: os vídeos se encaixam preenchendo a tela inteira sem bordas pretas.
                      </p>
                    </div>

                    <div className="space-y-3 pt-1">
                      {/* Encaixe de Vídeo */}
                      <div className="space-y-1.5">
                        <label className="text-[9px] text-zinc-400 uppercase font-mono font-bold block">
                          Formato de Exibição:
                        </label>
                        <div className="grid grid-cols-2 gap-2">
                          <button
                            type="button"
                            onClick={() => setVideoFit("cover")}
                            className={`px-2.5 py-2 rounded-lg font-mono text-[9px] font-bold uppercase transition-all cursor-pointer border flex flex-col items-center gap-1 text-center ${
                              videoFit === "cover"
                                ? "bg-[#00FF55]/15 text-[#00FF55] border-[#00FF55] shadow-sm"
                                : "bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-white"
                            }`}
                          >
                            <Maximize className="w-3.5 h-3.5" />
                            <span>Preencher Tela</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => setVideoFit("contain")}
                            className={`px-2.5 py-2 rounded-lg font-mono text-[9px] font-bold uppercase transition-all cursor-pointer border flex flex-col items-center gap-1 text-center ${
                              videoFit === "contain"
                                ? "bg-[#00FF55]/15 text-[#00FF55] border-[#00FF55] shadow-sm"
                                : "bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-white"
                            }`}
                          >
                            <Tv className="w-3.5 h-3.5" />
                            <span>Original</span>
                          </button>
                        </div>
                      </div>

                      {/* Auto Fullscreen on Start Toggle */}
                      <div className="flex items-center justify-between p-2.5 bg-zinc-950/60 rounded-xl border border-zinc-900">
                        <div className="space-y-0.5 pr-2">
                          <span className="text-[10px] font-mono font-bold text-zinc-300 block">
                            Tela Cheia ao Iniciar no Mobile
                          </span>
                          <span className="text-[8px] font-mono text-zinc-500 block">
                            Abre o reprodutor em tela cheia automaticamente no celular
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setMobileFullscreenAuto(prev => !prev)}
                          className={`w-9 h-5 rounded-full transition-colors relative cursor-pointer border border-zinc-800 shrink-0 ${
                            mobileFullscreenAuto ? "bg-[#00FF55]" : "bg-zinc-800"
                          }`}
                        >
                          <span
                            className={`w-3.5 h-3.5 rounded-full bg-black block absolute top-0.5 transition-transform ${
                              mobileFullscreenAuto ? "left-4.5" : "left-0.5"
                            }`}
                          />
                        </button>
                      </div>

                      {/* Test Fullscreen */}
                      <button
                        type="button"
                        onClick={() => {
                          setActiveTab("chat");
                          setTimeout(() => {
                            toggleFullscreen();
                          }, 100);
                        }}
                        className="w-full flex items-center justify-center gap-1.5 px-3 py-2 bg-zinc-900 hover:bg-zinc-850 text-zinc-200 hover:text-[#00FF55] border border-zinc-800 rounded-lg font-mono font-bold text-[9px] uppercase transition-all cursor-pointer shadow-sm active:scale-95"
                      >
                        <Maximize className="w-3.5 h-3.5 text-[#00FF55]" />
                        <span>Visualizar em Tela Cheia</span>
                      </button>
                    </div>
                  </div>

                  {/* Card 4: Diagnóstico & Habilitação do Microfone (Mobile & Desktop) */}
                  <div className="bg-zinc-900/40 border border-zinc-900 rounded-2xl p-4 flex flex-col justify-between text-left gap-3">
                    <div className="flex items-center justify-between border-b border-zinc-900 pb-2">
                      <span className="text-[10px] font-mono font-bold text-zinc-300 uppercase tracking-wide flex items-center gap-1.5">
                        <Mic className="w-3.5 h-3.5 text-[#00FF55]" />
                        Microfone no Celular (Mobile)
                      </span>
                      <span className={`text-[8px] font-mono px-2 py-0.5 rounded font-bold border ${
                        micPermission === "granted"
                          ? "bg-[#00FF55]/15 text-[#00FF55] border-[#00FF55]/30"
                          : micPermission === "denied"
                          ? "bg-red-500/15 text-red-400 border-red-500/30"
                          : "bg-amber-500/15 text-amber-300 border-amber-500/30"
                      }`}>
                        {micPermission === "granted" ? "LIBERADO" : micPermission === "denied" ? "BLOQUEADO" : "PENDENTE"}
                      </span>
                    </div>

                    <div className="space-y-3">
                      {/* Permission status & action button */}
                      <div className="p-2.5 bg-zinc-950/60 rounded-xl border border-zinc-900 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-[9px] font-mono text-zinc-400">Status de Permissão:</span>
                          <span className="text-[9px] font-mono font-bold text-zinc-200">
                            {micPermission === "granted" 
                              ? "Acesso Permitido" 
                              : micPermission === "denied"
                              ? "Bloqueado pelo Navegador"
                              : "Não Solicitado / Pendente"}
                          </span>
                        </div>

                        {/* Test / Enable Button */}
                        <button
                          type="button"
                          onClick={async () => {
                            const ok = await requestMicrophonePermission();
                            if (ok) {
                              setSpeechError("");
                            }
                          }}
                          className={`w-full py-2 px-3 rounded-lg font-mono font-black text-[9px] uppercase tracking-wide flex items-center justify-center gap-1.5 border transition-all cursor-pointer shadow-sm active:scale-95 ${
                            micPermission === "granted"
                              ? "bg-[#00FF55]/20 text-[#00FF55] border-[#00FF55]/40 hover:bg-[#00FF55] hover:text-black"
                              : "bg-[#00FF55] text-black border-black hover:bg-[#00FF55]/90"
                          }`}
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{micPermission === "granted" ? "Testar Microfone Novamente" : "Habilitar Microfone no Celular"}</span>
                        </button>
                      </div>

                      {/* Live Audio Level Bar (when listening or testing) */}
                      {(isListening || isRecordingMedia || audioLevel > 0) && (
                        <div className="p-2.5 bg-zinc-950/80 rounded-xl border border-zinc-800 space-y-1.5">
                          <div className="flex justify-between text-[8px] font-mono text-zinc-400">
                            <span>Sinal do Microfone:</span>
                            <span className="text-[#00FF55] font-bold">{audioLevel}%</span>
                          </div>
                          <div className="w-full bg-zinc-900 rounded-full h-2 overflow-hidden border border-zinc-800">
                            <div 
                              className="bg-[#00FF55] h-full transition-all duration-75"
                              style={{ width: `${audioLevel}%` }}
                            />
                          </div>
                        </div>
                      )}

                      {/* Engine Selector */}
                      <div className="space-y-1">
                        <span className="text-[9px] font-mono text-zinc-400 block">
                          Motor de Reconhecimento:
                        </span>
                        <div className="grid grid-cols-3 gap-1">
                          <button
                            type="button"
                            onClick={() => setPreferredSpeechEngine("auto")}
                            className={`py-1.5 px-1 rounded font-mono text-[8px] font-bold uppercase transition-all cursor-pointer border text-center ${
                              preferredSpeechEngine === "auto"
                                ? "bg-[#00FF55]/15 text-[#00FF55] border-[#00FF55]"
                                : "bg-zinc-950 text-zinc-400 border-zinc-900 hover:text-white"
                            }`}
                          >
                            Auto (Mobile)
                          </button>
                          <button
                            type="button"
                            onClick={() => setPreferredSpeechEngine("gemini")}
                            className={`py-1.5 px-1 rounded font-mono text-[8px] font-bold uppercase transition-all cursor-pointer border text-center ${
                              preferredSpeechEngine === "gemini"
                                ? "bg-[#00FF55]/15 text-[#00FF55] border-[#00FF55]"
                                : "bg-zinc-950 text-zinc-400 border-zinc-900 hover:text-white"
                            }`}
                          >
                            IA Gemini
                          </button>
                          <button
                            type="button"
                            onClick={() => setPreferredSpeechEngine("native")}
                            className={`py-1.5 px-1 rounded font-mono text-[8px] font-bold uppercase transition-all cursor-pointer border text-center ${
                              preferredSpeechEngine === "native"
                                ? "bg-[#00FF55]/15 text-[#00FF55] border-[#00FF55]"
                                : "bg-zinc-950 text-zinc-400 border-zinc-900 hover:text-white"
                            }`}
                          >
                            Nativo Web
                          </button>
                        </div>
                      </div>

                      {/* Help button for blocked permissions */}
                      <button
                        type="button"
                        onClick={() => setShowMicModal(true)}
                        className="w-full text-center text-[8px] font-mono text-zinc-400 hover:text-[#00FF55] underline cursor-pointer py-0.5"
                      >
                        O microfone não funciona? Ver instruções de desbloqueio
                      </button>
                    </div>
                  </div>

                </div>

                {/* Right Side: Voice Triggers Grid (Col Span: 8) */}
                <div className="lg:col-span-8 space-y-4">
                  
                  {/* Mini control bar */}
                  <div className="flex items-center justify-between border-b border-zinc-900 pb-2">
                    <span className="text-[11px] font-mono font-bold text-[#00FF55] uppercase tracking-wider flex items-center gap-1.5">
                      <Mic className="w-3.5 h-3.5" />
                      Gatilhos Cadastrados ({questions.length})
                    </span>
                  </div>

                  {/* Elegant Cards Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-[460px] overflow-y-auto pr-1">
                    {questions.map((q, idx) => (
                      <div
                        key={q.id}
                        className="bg-zinc-950/80 border border-zinc-900 hover:border-zinc-800 rounded-xl p-4 flex flex-col justify-between gap-3 text-left transition-all duration-200"
                      >
                        <div className="flex justify-between items-center border-b border-zinc-900 pb-2">
                          <span className="text-[10px] font-mono font-bold text-zinc-400 uppercase tracking-wide">
                            Canal #{idx + 1}
                          </span>
                          <div className="flex items-center gap-1.5">
                            {q.videoUrl && (
                              <span className="text-[8px] bg-[#00FF55]/10 text-[#00FF55] px-1.5 py-0.5 rounded font-extrabold font-mono border border-[#00FF55]/20">
                                ATIVO
                              </span>
                            )}
                            <button
                              type="button"
                              onClick={() => removeQuestion(q.id)}
                              className="text-zinc-550 hover:text-red-400 transition-colors p-1 cursor-pointer"
                              title="Excluir Gatilho"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        <div className="space-y-3">
                          
                          {/* Phrase input */}
                          <div className="space-y-1">
                            <label className="text-[9px] text-zinc-500 uppercase font-mono font-bold block">
                              Frase Ativadora:
                            </label>
                            <input
                              type="text"
                              className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#00FF55] rounded-lg px-2.5 py-1.5 text-[11px] text-zinc-100 focus:outline-none font-bold font-mono"
                              value={q.phrase}
                              onChange={(e) => updateQuestionPhrase(q.id, e.target.value)}
                              placeholder="Ex: mostrar floresta"
                            />
                          </div>

                          {/* Video file input */}
                          <div className="space-y-1">
                            <label className="text-[9px] text-zinc-500 uppercase font-mono font-bold block">
                              Vídeo Local (.mp4):
                            </label>
                            <label className="border border-dashed border-zinc-800 hover:border-[#00FF55]/50 bg-zinc-950/60 rounded-lg p-2 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-1 min-h-[55px]">
                              <input
                                type="file"
                                accept="video/*"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) handleFileChange(q.id, file);
                                }}
                                className="hidden"
                              />
                              <Upload className="w-3.5 h-3.5 text-zinc-650" />
                              {q.videoName ? (
                                <span className="text-[#00FF55] font-bold max-w-full truncate block px-1 text-[9px] font-mono">
                                  {q.videoName}
                                </span>
                              ) : (
                                <span className="text-zinc-500 font-mono text-[9px]">Importar arquivo</span>
                              )}
                            </label>
                          </div>

                          {/* Trigger test button */}
                          <button
                            type="button"
                            onClick={() => {
                              if (q.videoUrl) {
                                triggerVideoSlot(q.id);
                                setActiveTab("chat");
                              }
                            }}
                            disabled={!q.videoUrl}
                            className="w-full flex items-center justify-center gap-1 px-2.5 py-1.5 bg-zinc-900 hover:bg-zinc-850 active:bg-zinc-950 border border-zinc-800 rounded-lg text-zinc-350 hover:text-[#00FF55] disabled:opacity-35 disabled:pointer-events-none transition-all cursor-pointer font-bold font-mono text-[9px] uppercase shadow-sm"
                          >
                            Testar Canal em Tela Cheia
                          </button>
                        </div>
                      </div>
                    ))}

                    {/* Streamlined "Add" card trigger slot */}
                    <button
                      type="button"
                      onClick={addQuestion}
                      className="border border-dashed border-zinc-800 hover:border-[#00FF55]/50 rounded-xl p-4 flex flex-col justify-center items-center gap-2 hover:bg-zinc-900/25 transition-all cursor-pointer text-zinc-500 hover:text-zinc-300 min-h-[190px]"
                    >
                      <div className="w-10 h-10 rounded-full border border-dashed border-zinc-800 flex items-center justify-center text-zinc-500 group-hover:border-zinc-300">
                        <span className="text-base leading-none font-bold">+</span>
                      </div>
                      <div className="text-center">
                        <span className="text-[11px] font-bold uppercase tracking-wider font-mono block text-zinc-300">Novo Gatilho</span>
                        <span className="text-[9px] text-zinc-500 mt-1 max-w-[170px] block mx-auto leading-normal font-mono">
                          Associe um novo arquivo de vídeo a um comando.
                        </span>
                      </div>
                    </button>
                  </div>

                </div>

              </div>

            </div>

          </div>
        )}

      </main>

      {/* Clean Aesthetic Footer */}
      {!hidePanels && !isFullscreen && (
        <footer id="ecobot-footer" className="mt-auto py-6 border-t border-zinc-900 bg-zinc-950/80">
          <div className="max-w-5xl mx-auto px-6 flex flex-col sm:flex-row justify-between items-center text-[10px] font-mono text-zinc-650 gap-2">
            <span>ASSISTENTE WIT — PORTAL DE SUSTENTABILIDADE</span>
            <span>© CONEXÃO INTERATIVA DE VÍDEO</span>
          </div>
        </footer>
      )}

      {/* Floating Action Button to Restore Panels & Restart (Visible only when panels are hidden) */}
      {hidePanels && !isFullscreen && (
        <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-[600px] max-w-full h-24 bg-transparent flex items-end pb-4 justify-center pointer-events-auto z-50 group select-none">
          <div className="opacity-0 translate-y-3 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300 flex flex-wrap gap-4 justify-center">
            <button
              onClick={() => setHidePanels(false)}
              className="flex items-center gap-2.5 px-5 py-3.5 bg-black text-[#00FF55] hover:bg-[#00FF55] hover:text-black font-display font-black text-xs uppercase tracking-widest rounded-full border-3 border-black shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] hover:translate-y-[1px] hover:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] active:translate-y-[2px] active:shadow-none transition-all duration-300 cursor-pointer text-glow-emerald hover:text-glow-none"
              title="Mostrar Chat, Configurações e todos os controles de volta"
            >
              <Eye className="w-4 h-4 animate-pulse" />
              <span>Retornar com o Painel</span>
            </button>

            <button
              onClick={() => {
                setHasStarted(false);
                setHidePanels(false);
              }}
              className="flex items-center gap-2.5 px-5 py-3.5 bg-black text-rose-500 hover:bg-rose-500 hover:text-white font-display font-black text-xs uppercase tracking-widest rounded-full border-3 border-black shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] hover:translate-y-[1px] hover:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] active:translate-y-[2px] active:shadow-none transition-all duration-300 cursor-pointer"
              title="Reiniciar toda a experimentação e voltar para a tela inicial"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reiniciar Experimentação</span>
            </button>
          </div>
        </div>
      )}


      {/* Floating Microphone Action Button */}
      {activeTab === "chat" && !isFullscreen && (
        <div className="fixed bottom-6 right-6 z-[45] flex flex-col items-end gap-1.5 pointer-events-auto animate-fade-in">
          <div className="flex items-center gap-1.5 bg-zinc-950/95 border-2 border-black px-2.5 py-1 rounded-full shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] text-[8px] font-mono font-bold uppercase transition-all duration-300">
            <span className={`w-1.5 h-1.5 rounded-full ${isListening || isRecordingMedia ? "bg-red-500 animate-pulse" : "bg-[#00FF55]"}`} />
            <span className={isListening || isRecordingMedia ? "text-red-400 font-extrabold animate-pulse" : "text-zinc-400"}>
              {isListening || isRecordingMedia ? (isRecordingMedia ? `GRAVANDO ${recordingDuration}s` : "ESCUTA ATIVA") : "CLIQUE P/ FALAR"}
            </span>
          </div>
          <button
            type="button"
            onClick={toggleListening}
            className={`w-14 h-14 rounded-full flex items-center justify-center transition-all border-3 border-black cursor-pointer shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 active:translate-y-1 active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] ${
              isListening || isRecordingMedia
                ? "bg-red-500 text-white shadow-[0_0_15px_rgba(239,68,68,0.45)]"
                : "bg-[#00FF55] text-black hover:bg-[#00FF55]/90"
            }`}
            title={isListening || isRecordingMedia ? "Desativar escuta de voz" : "Ativar microfone por voz"}
          >
            {isListening || isRecordingMedia ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5 animate-pulse" />}
          </button>
        </div>
      )}

      {/* Mobile Microphone Permission Guide Modal */}
      {showMicModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-[9999] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-zinc-950 border-3 border-black rounded-3xl w-full max-w-lg p-6 flex flex-col gap-4 text-zinc-100 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] text-left">
            <div className="flex items-center justify-between border-b border-zinc-900 pb-3">
              <div className="flex items-center gap-2">
                <Mic className="w-5 h-5 text-[#00FF55]" />
                <h3 className="font-display font-black text-sm uppercase tracking-wider text-white">
                  Como Habilitar o Microfone no Celular
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowMicModal(false)}
                className="text-zinc-500 hover:text-white p-1 text-xs font-mono font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs font-mono">
              <p className="text-zinc-300 leading-relaxed">
                Para responder por voz aos vídeos da EcoSphere no celular, o navegador precisa da sua autorização para captar áudio:
              </p>

              {/* Android Instructions */}
              <div className="p-3 bg-zinc-900/60 rounded-xl border border-zinc-800 space-y-1.5">
                <span className="text-[#00FF55] font-bold block uppercase text-[10px] flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5" />
                  No Android (Google Chrome):
                </span>
                <ol className="list-decimal list-inside space-y-1 text-zinc-300 text-[11px]">
                  <li>Toque no ícone de <strong>configurações de site</strong> (à esquerda da URL).</li>
                  <li>Toque em <strong>Permissões</strong> &gt; <strong>Microfone</strong>.</li>
                  <li>Marque como <strong>Permitir</strong>.</li>
                </ol>
              </div>

              {/* iPhone / Safari Instructions */}
              <div className="p-3 bg-zinc-900/60 rounded-xl border border-zinc-800 space-y-1.5">
                <span className="text-[#00FF55] font-bold block uppercase text-[10px] flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5" />
                  No iPhone / iPad (Safari):
                </span>
                <ol className="list-decimal list-inside space-y-1 text-zinc-300 text-[11px]">
                  <li>Toque no botão <strong>aA</strong> na barra de endereços do Safari.</li>
                  <li>Selecione <strong>Ajustes do Site</strong>.</li>
                  <li>Em <strong>Microfone</strong>, escolha <strong>Permitir</strong>.</li>
                </ol>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row justify-end gap-2.5 mt-2 border-t border-zinc-900 pt-3">
              <button
                type="button"
                onClick={() => setShowMicModal(false)}
                className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-mono text-[10px] font-bold uppercase rounded-lg border border-zinc-800 transition-all cursor-pointer"
              >
                Fechar
              </button>
              <button
                type="button"
                onClick={async () => {
                  const ok = await requestMicrophonePermission();
                  if (ok) {
                    setShowMicModal(false);
                    setSpeechError("");
                  }
                }}
                className="px-4 py-2 bg-[#00FF55] hover:bg-[#00FF55]/90 text-black font-mono text-[10px] font-black uppercase rounded-lg border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Autorizar e Testar Microfone Agora</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom Confirmation Dialog Modal */}
      {confirmModal && confirmModal.isOpen && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-[9999] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-zinc-950 border-3 border-black rounded-3xl w-full max-w-md p-6 flex flex-col gap-4 text-zinc-100 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] text-left">
            <h3 className="font-display font-black text-sm uppercase tracking-wider text-[#00FF55] border-b border-zinc-900 pb-2">
              {confirmModal.title}
            </h3>
            <p className="text-xs text-zinc-300 font-mono leading-relaxed">
              {confirmModal.message}
            </p>
            <div className="flex justify-end gap-3 mt-2">
              <button
                type="button"
                onClick={() => setConfirmModal(null)}
                className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-mono text-[10px] font-bold uppercase rounded-lg border border-zinc-800 transition-all cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  confirmModal.onConfirm();
                  setConfirmModal(null);
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-mono text-[10px] font-black uppercase rounded-lg border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:translate-y-[0.5px] hover:shadow-[1.5px_1.5px_0px_0px_rgba(0,0,0,1)] active:translate-y-[1px] active:shadow-none transition-all cursor-pointer"
              >
                Confirmar
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
