import fs from 'fs';

const content = fs.readFileSync('src/App.tsx', 'utf8');
const lines = content.split(/\r?\n/);

// Simulate line 1708 having </div>
lines[1707] = '            </div>';

const stack: { tag: string; line: number; text: string }[] = [];

for (let i = 1176; i < 1709; i++) {
  const lineNum = i + 1;
  const line = lines[i];
  
  const tagRegex = /<\/?([a-zA-Z0-9:-]+)(?:\s+[^>]*?)?>/g;
  let match;
  while ((match = tagRegex.exec(line)) !== null) {
    const fullTag = match[0];
    const tagName = match[1];
    
    if (fullTag.endsWith('/>')) continue;
    if (['br', 'hr', 'img', 'input', 'meta', 'link', 'path', 'rect', 'circle', 'svg'].includes(tagName.toLowerCase())) continue;
    
    const isClosing = fullTag.startsWith('</');
    
    if (isClosing) {
      if (stack.length === 0) {
        // console.log(`EXTRA closing tag </${tagName}> on line ${lineNum}: ${line.trim()}`);
      } else {
        const top = stack.pop()!;
        if (top.tag !== tagName) {
          // Put it back
          stack.push(top);
        }
      }
    } else {
      stack.push({ tag: tagName, line: lineNum, text: line.trim() });
    }
  }
}

console.log("\nUNCLOSED TAGS AT END OF SETTINGS BLOCK (WITH LINE 1708 RESTORED):");
stack.forEach(s => {
  console.log(`- <${s.tag}> opened on line ${s.line}: ${s.text}`);
});
