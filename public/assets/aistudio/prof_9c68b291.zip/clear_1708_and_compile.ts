import fs from 'fs';
import { execSync } from 'child_process';

const filePath = 'src/App.tsx';
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split(/\r?\n/);

// Make line 1708 (index 1707) empty
lines[1707] = '';

fs.writeFileSync(filePath, lines.join('\n'));
console.log("Cleared line 1708 successfully.");

try {
  console.log("Running npm run build...");
  const output = execSync('npm run build', { encoding: 'utf8', stdio: 'pipe' });
  console.log("BUILD SUCCEEDED!\n", output);
} catch (err: any) {
  console.log("BUILD FAILED!");
  console.log("STDOUT:\n", err.stdout);
  console.log("STDERR:\n", err.stderr);
}
