import fs from 'fs';

const content = fs.readFileSync('src/App.tsx', 'utf8');

let i = 0;
let line = 1;
let col = 1;

let curlyStack: { line: number; col: number; char: string }[] = [];
let parenStack: { line: number; col: number; char: string }[] = [];

while (i < content.length) {
  const char = content[i];
  
  // Track line/col
  if (char === '\n') {
    line++;
    col = 1;
    i++;
    continue;
  }
  
  // Skip single-line comments
  if (content.substr(i, 2) === '//') {
    while (i < content.length && content[i] !== '\n') {
      i++;
    }
    continue;
  }
  
  // Skip multi-line comments
  if (content.substr(i, 2) === '/*') {
    i += 2;
    while (i < content.length && content.substr(i, 2) !== '*/') {
      if (content[i] === '\n') {
        line++;
        col = 1;
      } else {
        col++;
      }
      i++;
    }
    i += 2;
    continue;
  }
  
  // Skip string literals (double quotes)
  if (char === '"') {
    i++;
    while (i < content.length && content[i] !== '"') {
      if (content[i] === '\\') i++; // skip escaped
      if (content[i] === '\n') {
        line++;
        col = 1;
      } else {
        col++;
      }
      i++;
    }
    i++;
    continue;
  }
  
  // Skip string literals (single quotes)
  if (char === "'") {
    i++;
    while (i < content.length && content[i] !== "'") {
      if (content[i] === '\\') i++; // skip escaped
      if (content[i] === '\n') {
        line++;
        col = 1;
      } else {
        col++;
      }
      i++;
    }
    i++;
    continue;
  }
  
  // Skip template literals (ticks)
  if (char === '`') {
    i++;
    while (i < content.length && content[i] !== '`') {
      // Handle nested expressions ${...} inside template literals!
      if (content.substr(i, 2) === '${') {
        curlyStack.push({ line, col, char: '${' });
        i += 2;
        col += 2;
        continue;
      }
      if (content[i] === '\\') i++; // skip escaped
      if (content[i] === '\n') {
        line++;
        col = 1;
      } else {
        col++;
      }
      i++;
    }
    i++;
    continue;
  }
  
  // Count braces
  if (char === '{') {
    curlyStack.push({ line, col, char: '{' });
  } else if (char === '}') {
    if (curlyStack.length === 0) {
      console.log(`EXTRA '}' at line ${line}, col ${col}`);
    } else {
      const top = curlyStack.pop()!;
    }
  } else if (char === '(') {
    parenStack.push({ line, col, char: '(' });
  } else if (char === ')') {
    if (parenStack.length === 0) {
      console.log(`EXTRA ')' at line ${line}, col ${col}`);
    } else {
      parenStack.pop();
    }
  }
  
  i++;
  col++;
}

console.log("\nUNCLOSED BRACES LEFT IN STACK:");
curlyStack.forEach(c => {
  console.log(`- ${c.char} at line ${c.line}, col ${c.col}`);
});

console.log("\nUNCLOSED PARENTHESES LEFT IN STACK:");
parenStack.forEach(p => {
  console.log(`- ${p.char} at line ${p.line}, col ${p.col}`);
});
