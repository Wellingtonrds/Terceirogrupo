import React, { useState, useEffect, useRef } from "react";
import { 
  Mic, 
  MicOff, 
  Send, 
  Tv, 
  Upload, 
  RotateCcw,
  Volume2,
  VolumeX,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  Settings,
  MessageSquare,
  HelpCircle,
  Video,
  Cloud,
  Database,
  Folder,
  FolderOpen,
  Chrome,
  LogOut,
  Eye,
  EyeOff,
  Copy,
  Check,
  Trash2,
  Play
} from "lucide-react";
import { Trigger } from "./types";

interface CustomQuestion {
  id: string;
  phrase: string;
  videoUrl: string;
  videoName: string;
}

export default function App() {
  // Navigation: state to change between the interactive screen "chat" and "settings"
  const [activeTab, setActiveTab] = useState<"chat" | "settings">("chat");

  // Dynamic Questions List State
  const [questions, setQuestions] = useState<CustomQuestion[]>(() => {
    try {
      const saved = localStorage.getItem("eco_custom_questions");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((q: any) => ({
            id: q.id,
            phrase: q.phrase || "",
            videoUrl: "", // Object/Blob URLs expire across page refreshes
            videoName: q.videoName || ""
          }));
        }
      }
    } catch (e) {
      console.error("Failed to load eco_custom_questions:", e);
    }

    // Default 2 questions
    return [
      { id: "questionA", phrase: "mostrar natureza", videoUrl: "", videoName: "" },
      { id: "questionB", phrase: "mostrar chuva", videoUrl: "", videoName: "" }
    ];
  });

  // Local object URLs for video files (stored in state for active session)
  const [introUrl, setIntroUrl] = useState<string>("");
  const [introName, setIntroName] = useState(() => localStorage.getItem("eco_intro_name") || "");

  // Active slot corresponds to either "intro" or any question id
  const [activeVideoSlot, setActiveVideoSlot] = useState<string>("intro");

  // Chat conversation state
  const [inputText, setInputText] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [lastSpeechDetected, setLastSpeechDetected] = useState<string>("");
  const [realtimeSpeech, setRealtimeSpeech] = useState<string>("");
  const [speechError, setSpeechError] = useState("");
  const [aiResponseText, setAiResponseText] = useState<string>(
    "Canal pronto. Clique no microfone ou digite abaixo para falar um dos comandos configurados."
  );

  // Playback settings
  const [videoMuted, setVideoMuted] = useState(true);
  const [videoPlayError, setVideoPlayError] = useState<string>("");
  const [isListening, setIsListening] = useState(false);
  const [showReplayPrompt, setShowReplayPrompt] = useState(false);
  const [viewedSlots, setViewedSlots] = useState<string[]>([]);
  const [videoFinished, setVideoFinished] = useState<boolean>(false);
  const [videoFit, setVideoFit] = useState<"contain" | "cover">("contain");
  const [hidePanels, setHidePanels] = useState<boolean>(false);
  const [hasStarted, setHasStarted] = useState<boolean>(false);
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);

  // Web Speech API references
  const recognitionRef = useRef<any>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Helper helper to clean and evaluate similarity between recognized text and target phrases
  const getFuzzyMatchScore = (input: string, targetPhrase: string): number => {
    if (!input || !targetPhrase) return 0;
    
    const cleanString = (s: string) => {
      return s
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "") // remove accents
        .replace(/[^a-z0-9\s]/g, "") // remove punctuation
        .trim();
    };

    const inputClean = cleanString(input);
    const targetClean = cleanString(targetPhrase);

    if (!inputClean || !targetClean) return 0;

    // Exact match
    if (inputClean === targetClean) return 1.0;

    // Substring contains
    if (inputClean.includes(targetClean) || targetClean.includes(inputClean)) {
      return 0.95;
    }

    // Split words to see the intersection of keywords (plurals and verb stems)
    const inputWords = inputClean.split(/\s+/).filter(w => w.length > 1);
    const targetWords = targetClean.split(/\s+/).filter(w => w.length > 2);

    if (targetWords.length === 0) return 0;

    let matchCount = 0;
    for (const tWord of targetWords) {
      const matched = inputWords.some(iWord => {
        if (iWord === tWord) return true;
        // Check partial word prefixes to match e.g. "mostra" and "mostrar", "chuva" and "chuvas", etc.
        const minLen = Math.min(tWord.length, iWord.length);
        if (minLen >= 4) {
          const prefixT = tWord.substring(0, 4);
          const prefixI = iWord.substring(0, 4);
          if (prefixT === prefixI) return true;
        }
        return false;
      });
      if (matched) matchCount++;
    }

    return matchCount / targetWords.length;
  };

  // Sync state metadata to localStorage
  useEffect(() => {
    localStorage.setItem("eco_intro_name", introName);
    
    const configToSave = questions.map(q => ({
      id: q.id,
      phrase: q.phrase,
      videoName: q.videoName
    }));
    localStorage.setItem("eco_custom_questions", JSON.stringify(configToSave));
  }, [questions, introName]);

  // Web Speech API driver setup
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      console.warn("Speech recognition not supported in this browser.");
      return;
    }

    const rec = new SpeechRecognition();
    rec.continuous = false;
    rec.lang = "pt-BR";
    rec.interimResults = true; // Enabled true for real-time transcription feedback
    rec.maxAlternatives = 1;

    rec.onstart = () => {
      setIsListening(true);
      setSpeechError("");
      setRealtimeSpeech("");
    };

    rec.onresult = (event: any) => {
      let interimTranscript = "";
      let finalTranscript = "";

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }

      if (interimTranscript) {
        setRealtimeSpeech(interimTranscript);
      }

      if (finalTranscript) {
        setLastSpeechDetected(finalTranscript);
        setRealtimeSpeech("");
        setIsListening(false);
        handleIncomingCommand(finalTranscript);
      }
    };

    rec.onerror = (event: any) => {
      setIsListening(false);
      setRealtimeSpeech("");
      if (event.error === "not-allowed") {
        setSpeechError("Acesso ao microfone negado.");
      } else if (event.error === "no-speech") {
        setSpeechError("Nenhuma fala detectada.");
      } else {
        setSpeechError(`Erro no microfone: ${event.error}`);
      }
    };

    rec.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = rec;
    return () => {
      rec.abort();
    };
  }, [questions]);

  // Play and reload helper triggered on video changes
  const activeVideoUrl = (() => {
    if (activeVideoSlot === "intro") {
      return introUrl;
    }
    const match = questions.find(q => q.id === activeVideoSlot);
    if (match) {
      return match.videoUrl;
    }
    return "";
  })();

  useEffect(() => {
    setShowReplayPrompt(false);
    setVideoFinished(false);
    if (videoRef.current) {
      const v = videoRef.current;
      setVideoPlayError("");
      try {
        v.load();
        const playPromise = v.play();
        if (playPromise !== undefined) {
          playPromise.catch((err) => {
            console.warn("Automatic play delayed/prevented:", err);
          });
        }
      } catch (err) {
        console.error("Video load error:", err);
      }
    }
  }, [activeVideoSlot, activeVideoUrl]);

  // Handle local video files selection
  const handleFileChange = (slotId: string, file: File) => {
    const url = URL.createObjectURL(file);
    if (slotId === "intro") {
      setIntroUrl(url);
      setIntroName(file.name);
      setActiveVideoSlot("intro");
    } else {
      setQuestions(prev => prev.map(q => {
        if (q.id === slotId) {
          return { ...q, videoUrl: url, videoName: file.name };
        }
        return q;
      }));
      setActiveVideoSlot(slotId);
    }
  };

  // Add questions helper
  const addQuestion = () => {
    const newId = `trigger_${Date.now()}`;
    setQuestions(prev => [
      ...prev,
      {
        id: newId,
        phrase: `nova resposta ${prev.length + 1}`,
        videoUrl: "",
        videoName: ""
      }
    ]);
  };

  // Remove question helper
  const removeQuestion = (id: string) => {
    setConfirmModal({
      isOpen: true,
      title: "Excluir Gatilho",
      message: "Deseja mesmo excluir este gatilho de ativação por voz? Essa ação não pode ser desfeita.",
      onConfirm: () => {
        setQuestions(prev => prev.filter(q => q.id !== id));
        if (activeVideoSlot === id) {
          setActiveVideoSlot("intro");
        }
      }
    });
  };

  const updateQuestionPhrase = (id: string, phrase: string) => {
    setQuestions(prev => prev.map(q => {
      if (q.id === id) {
        return { ...q, phrase };
      }
      return q;
    }));
  };

  // Toggle voice listening trigger
  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      if (recognitionRef.current) {
        try {
          setRealtimeSpeech("");
          setSpeechError("");
          recognitionRef.current.start();
        } catch (err) {
          console.error("Mic start error:", err);
        }
      } else {
        setSpeechError("Microfone indisponível ou permissão bloqueada no navegador.");
      }
    }
  };

  const getActiveVideoUrl = () => {
    return activeVideoUrl;
  };

  const getActiveVideoTitle = () => {
    if (activeVideoSlot === "intro") return `APRESENTAÇÃO INICIAL: ${introName || "Sem Arquivo"}`;
    const match = questions.find(q => q.id === activeVideoSlot);
    if (match) {
      return `PROJEÇÃO: ${match.phrase.toUpperCase()} (${match.videoName || "Sem Arquivo"})`;
    }
    return "APRESENTAÇÃO INICIAL";
  };

  const isIntroSpecialVideo = activeVideoSlot === "intro" && (
    introName === "WhatsApp Video 2026-06-12 at 08.35.25.mp4" ||
    introName === "WhatsApp Video 2026-06-12 at 08.35.25" ||
    introName?.includes("WhatsApp Video 2026-06-12 at 08.35.25.mp4") ||
    getActiveVideoTitle() === "APRESENTAÇÃO INICIAL: WhatsApp Video 2026-06-12 at 08.35.25.mp4"
  );

  const playableSlots = [
    ...(introUrl ? ["intro"] : []),
    ...questions.filter(q => q.videoUrl).map(q => q.id)
  ];

  const allVideosPlayed = playableSlots.length > 0 && playableSlots.every(slot => viewedSlots.includes(slot));

  const resetAllTriggers = () => {
    setConfirmModal({
      isOpen: true,
      title: "Redefinir Tudo",
      message: "Deseja apagar todos os vídeos carregados e redefinir as frases de ativação para o padrão?",
      onConfirm: () => {
        setIntroUrl("");
        setIntroName("");
        setQuestions([
          { id: "questionA", phrase: "mostrar natureza", videoUrl: "", videoName: "" },
          { id: "questionB", phrase: "mostrar chuva", videoUrl: "", videoName: "" }
        ]);
        setActiveVideoSlot("intro");
        setLastSpeechDetected("");
        setRealtimeSpeech("");
        setAiResponseText("Ajustes redefinidos. Vá na janela de configurações para carregar vídeos locais.");
      }
    });
  };

  // Main voice commander parser & matcher to trigger projection shifts
  const handleIncomingCommand = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed) return;

    const lowerText = trimmed.toLowerCase();

    // Hands-free voice commands requested by the user
    if (
      lowerText.includes("rever") || 
      lowerText.includes("reassistir") || 
      lowerText.includes("reproduzir novamente") || 
      lowerText.includes("ver de novo") ||
      lowerText.includes("rever video") ||
      lowerText.includes("rever vídeo")
    ) {
      setVideoFinished(false);
      if (videoRef.current) {
        videoRef.current.currentTime = 0;
        const playPromise = videoRef.current.play();
        if (playPromise !== undefined) {
          playPromise.catch(err => console.warn("Failed to play: ", err));
        }
      }
      setAiResponseText("Vídeo reiniciado via comando de voz.");
      setIsAnalyzing(false);
      return;
    }

    if (
      lowerText.includes("iniciar do zero") || 
      lowerText.includes("iniciar do xzero") || 
      lowerText.includes("reiniciar") || 
      lowerText.includes("do zero") || 
      lowerText.includes("do xzero") || 
      lowerText.includes("iniciar do o0") || 
      lowerText.includes("do o0") ||
      lowerText.includes("começar do zero")
    ) {
      setViewedSlots([]);
      setVideoFinished(false);
      setActiveVideoSlot("intro");
      setAiResponseText("Visita reiniciada do zero via comando de voz.");
      setIsAnalyzing(false);
      return;
    }

    setLastSpeechDetected(trimmed);
    setInputText("");
    setIsAnalyzing(true);
    setSpeechError("");

    const virtualTriggers: Trigger[] = [
      { id: "intro", phrase: "introdução", videoUrl: introUrl, description: "Introdução ou início" },
      ...questions.map(q => ({
        id: q.id,
        phrase: q.phrase,
        videoUrl: q.videoUrl,
        description: `Pergunta: ${q.phrase}`
      }))
    ];

    try {
      // Calculate direct alignment scores with our optimized fuzzy word matcher
      const scores = questions.map(q => ({
        id: q.id,
        phrase: q.phrase,
        score: getFuzzyMatchScore(trimmed, q.phrase)
      }));

      // Common phrases for intro/home/reset
      const introPhrases = ["introducao", "introdução", "inicio", "iniciar", "voltar", "comeco", "começo", "começar", "apresentação"];
      const scoreIntro = Math.max(...introPhrases.map(p => getFuzzyMatchScore(trimmed, p)));

      // Find the highest score among questions
      const bestMatch = scores.reduce((best, curr) => curr.score > best.score ? curr : best, { id: "", phrase: "", score: 0 });

      console.log(`[Scores] Best Match: "${bestMatch.phrase}" (${bestMatch.score}) | Intro: ${scoreIntro}`);

      // We privilege clear fuzzy score matches over contacting a server (keeps app instantaneous if confident)
      if (bestMatch.score >= 0.5 && bestMatch.score >= scoreIntro) {
        setActiveVideoSlot(bestMatch.id);
        setAiResponseText(`[Sintonia] Comando de voz correspondido! Transmitindo Vídeo: "${bestMatch.phrase}"`);
        setIsAnalyzing(false);
        return;
      } else if (scoreIntro >= 0.5 && scoreIntro >= bestMatch.score) {
        setActiveVideoSlot("intro");
        setAiResponseText("[Sintonia] Voltando à apresentação inicial.");
        setIsAnalyzing(false);
        return;
      }

      // Query server for smart fallback matching if fuzzy metrics are ambiguous
      const response = await fetch("/api/gemini/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          input: trimmed,
          triggers: virtualTriggers
        })
      });

      if (!response.ok) {
        throw new Error("Erro de resposta do servidor de análise.");
      }

      const result = await response.json();
      const matchedId = result.matchedTriggerId;
      
      if (matchedId === "intro") {
        setActiveVideoSlot("intro");
        setAiResponseText(result.response || "Comando de retorno correspondido. Sintonizando introdução inicial.");
      } else if (matchedId) {
        const matchedQuestion = questions.find(q => q.id === matchedId);
        if (matchedQuestion) {
          setActiveVideoSlot(matchedId);
          setAiResponseText(result.response || `Entendi! Sintonizando o Vídeo correspondente a: "${matchedQuestion.phrase}"`);
        } else {
          setAiResponseText(`Comando não identificado. Por favor, fale um comando configurado.`);
        }
      } else {
        const phrasesList = questions.map(q => `"${q.phrase}"`).join(" ou ");
        setAiResponseText(`Comando não identificado. Por favor, fale um comando configurado: ${phrasesList}.`);
      }

    } catch (err) {
      // Local strict offline fallback matcher
      const scores = questions.map(q => ({
        id: q.id,
        phrase: q.phrase,
        score: getFuzzyMatchScore(trimmed, q.phrase)
      }));
      const bestMatch = scores.reduce((best, curr) => curr.score > best.score ? curr : best, { id: "", phrase: "", score: 0 });

      if (bestMatch.score > 0.35) {
        setActiveVideoSlot(bestMatch.id);
        setAiResponseText(`[Sintonizado] Vídeo correspondido.`);
      } else {
        const phrasesList = questions.map(q => `"${q.phrase}"`).join(" ou ");
        setAiResponseText(`Não foi possível compreender "${trimmed}". Diga exatamente ${phrasesList}.`);
      }
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div id="ecobot-root" className="min-h-screen bg-[#09090b] text-zinc-100 font-sans flex flex-col selection:bg-[#00FF55] selection:text-black">
      
      {/* Waveform keyframe for active recording state */}
      <style>{`
        @keyframes customGrow {
          0%, 100% { height: 6px; }
          50% { height: 24px; }
        }
        .v-wave-1 { animation: customGrow 0.5s infinite ease-in-out; }
        .v-wave-2 { animation: customGrow 0.7s infinite ease-in-out 0.12s; }
        .v-wave-3 { animation: customGrow 0.4s infinite ease-in-out 0.24s; }
        .v-wave-4 { animation: customGrow 0.6s infinite ease-in-out 0.36s; }
        .text-glow-emerald {
          text-shadow: 0 0 12px rgba(0, 255, 85, 0.4);
        }
      `}</style>

      {/* Simplified, neat Navigation Row */}
      {!hidePanels && (
        <header id="ecobot-nav" className="bg-[#09090b] border-b border-zinc-900/60 py-4 px-6 sticky top-0 z-20">
          <div className="max-w-7xl mx-auto flex items-center justify-between relative">
            
            {/* Left side: Active status indicator */}
            <div className="flex items-center gap-2 select-none">
              <span className="w-2 h-2 rounded-full bg-[#00FF55] animate-pulse" />
              <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest hidden sm:inline">assistente wit live</span>
            </div>

            {/* CENTER: Assistente Wit brand title */}
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 select-none">
              <span className="font-display font-black text-xl sm:text-2xl tracking-[0.15em] text-[#00FF55] text-glow-emerald uppercase leading-none whitespace-nowrap">
                Assistente Wit
              </span>
            </div>

            {/* Right Action buttons: Configurações & Reset tab swappers */}
            <div className="flex items-center gap-2">
              {activeTab === "chat" && hasStarted && (
                <button
                  onClick={toggleListening}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[10px] font-mono font-bold tracking-tight uppercase transition-all duration-300 border-2 cursor-pointer ${
                    isListening
                      ? "bg-red-500 text-white border-black shadow-[0_0_10px_rgba(239,68,68,0.3)] animate-pulse"
                      : "bg-[#00FF55]/15 text-[#00FF55] border-[#00FF55]/30 hover:bg-[#00FF55] hover:text-black hover:border-black"
                  }`}
                  title={isListening ? "Desativar microfone" : "Ativar microfone por voz"}
                >
                  {isListening ? (
                    <>
                      <MicOff className="w-3.5 h-3.5" />
                      <span>Falar: ON</span>
                    </>
                  ) : (
                    <>
                      <Mic className="w-3.5 h-3.5" />
                      <span>Falar: OFF</span>
                    </>
                  )}
                </button>
              )}

              <button
                onClick={() => setActiveTab(activeTab === "chat" ? "settings" : "chat")}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-[10px] font-mono font-bold tracking-tight uppercase transition-all duration-300 border border-zinc-800 bg-zinc-950 text-zinc-400 hover:text-[#00FF55] hover:border-[#00FF55]/40 cursor-pointer ${
                  activeTab === "settings" ? "text-[#00FF55] border-[#00FF55]/30 bg-[#00FF55]/5" : ""
                }`}
                title={activeTab === "chat" ? "Ir para Configurações" : "Ir para o Player"}
              >
                {activeTab === "chat" ? (
                  <>
                    <Settings className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Configurações</span>
                  </>
                ) : (
                  <>
                    <Tv className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Player</span>
                  </>
                )}
              </button>
            </div>

          </div>
        </header>
      )}

      {/* Main Area */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 py-8 flex flex-col justify-start transition-all duration-300">
        
        {/* VIEW 1: CHAT & PROJECTION (Simplified, dedicated single panel for interaction) */}
        {activeTab === "chat" && (
          <div className="space-y-6 animate-fade-in max-w-7xl mx-auto w-full transition-all duration-300">
            
            <div className="max-w-5xl mx-auto w-full flex flex-col gap-8">
              
              {/* Centered Video Stream Box Container */}
              <div className="w-full relative pt-10">
                
                {/* Main Video Box */}
                <div className="bg-zinc-950 border-3 border-black rounded-3xl relative min-h-[300px] md:min-h-[440px] flex flex-col justify-center items-center group shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all duration-300">
                  
                  
                  {/* Inner overflow-hidden container to round off borders correctly */}
                  <div className="absolute inset-0 rounded-[22px] overflow-hidden flex flex-col justify-center items-center">
                    
                    {/* Floating Layout Toggles Overlay (Always Accessible in Upper Right) */}
                    <div className="absolute top-3 right-3 z-30 flex items-center gap-1.5 bg-black/50 backdrop-blur-sm p-1 rounded-lg border border-zinc-800">
                      <button
                        onClick={() => setVideoFit(prev => prev === "contain" ? "cover" : "contain")}
                        className="bg-black/95 hover:bg-[#00FF55] hover:text-black hover:border-black border border-zinc-800 hover:scale-105 text-[#00FF55] text-[9px] font-mono font-black uppercase px-2 py-1.5 rounded transition-all cursor-pointer flex items-center gap-1 shadow-sm"
                        title={videoFit === "contain" ? "Preencher Tela (Ajustar Vídeo)" : "Enquadramento Original Proporcional"}
                      >
                        <Tv className="w-3.2 h-3.2" />
                        <span>{videoFit === "contain" ? "Preencher" : "Original"}</span>
                      </button>

                      <button
                        onClick={() => setHidePanels(prev => !prev)}
                        className={`bg-black/95 hover:bg-[#00FF55] hover:text-black hover:border-black border border-zinc-800 hover:scale-105 text-[#00FF55] text-[9px] font-mono font-black uppercase px-2 py-1.5 rounded transition-all cursor-pointer flex items-center gap-1 shadow-sm ${hidePanels ? "bg-[#00FF55] text-black border-black" : ""}`}
                        title={hidePanels ? "Mostrar Painel, Chat e Opções de Controle" : "Ocultar Informações para Focar no Vídeo"}
                      >
                        {hidePanels ? <Eye className="w-3.2 h-3.2" /> : <EyeOff className="w-3.2 h-3.2" />}
                        <span>{hidePanels ? "Ver Painel" : "Ocultar"}</span>
                      </button>
                    </div>

                    {!hasStarted ? (
                      <div className="absolute inset-0 bg-zinc-950 flex flex-col items-center justify-center p-8 text-center z-40 animate-fade-in text-zinc-300">
                        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,255,85,0.15)_0%,transparent_70%)] opacity-70 pointer-events-none" />
                        
                        <div className="relative mb-6">
                          <div className="w-20 h-20 rounded-full bg-zinc-900 border-2 border-[#00FF55] flex items-center justify-center text-[#00FF55] shadow-[0_0_20px_rgba(0,255,85,0.25)] animate-pulse">
                            <Sparkles className="w-8 h-8 text-[#00FF55]" />
                          </div>
                        </div>

                        <div className="space-y-3 max-w-sm">
                          <h4 className="font-display font-black text-lg md:text-xl text-white uppercase tracking-wider leading-tight">
                            Bem-vindo ao Assistente Wit
                          </h4>
                        </div>

                        <button
                          onClick={() => {
                            setHasStarted(true);
                            setVideoMuted(false); // Enable direct audio feedback instantly because we have user gesture!
                            // Try to trigger video play after state transition
                            setTimeout(() => {
                              if (videoRef.current) {
                                videoRef.current.currentTime = 0;
                                const p = videoRef.current.play();
                                if (p !== undefined) {
                                  p.catch(err => console.warn("Video failed to play after starting:", err));
                                }
                              }
                            }, 50);
                          }}
                          className="mt-8 px-6 py-3.5 bg-[#00FF55] text-black font-display font-black text-xs uppercase tracking-widest rounded-xl border-3 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:translate-y-[1px] hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-y-[3px] active:shadow-none hover:bg-white hover:text-black transition-all cursor-pointer select-none"
                        >
                          Iniciar Experimentação
                        </button>
                      </div>
                    ) : getActiveVideoUrl() ? (
                      <div className="absolute inset-0 bg-black flex items-center justify-center">
                        <video
                          key={activeVideoSlot}
                          ref={videoRef}
                          src={getActiveVideoUrl()}
                          className={`w-full h-full ${videoFit === "contain" ? "object-contain" : "object-cover"} ${videoFinished ? "blur-[2.5px]" : ""} transition-all duration-500`}
                          autoPlay
                          muted={videoMuted}
                          playsInline
                          onEnded={() => {
                            setVideoFinished(true);
                            setShowReplayPrompt(true);
                            setViewedSlots((prev) => {
                              if (prev.includes(activeVideoSlot)) return prev;
                              return [...prev, activeVideoSlot];
                            });
                          }}
                          onError={() => {
                            setVideoPlayError("Não foi possível reproduzir este arquivo de vídeo local.");
                          }}
                        />

                        {/* END OF VIDEO: SPINNER OR THANK YOU OVERLAYS */}
                        {videoFinished && (
                          <div className="absolute inset-0 bg-black/45 backdrop-blur-[1px] flex flex-col items-center justify-center p-6 z-20 animate-fade-in select-none">
                            {/* 2. QUESTIONS (PERGUNTAS) ON SCREEN - Displaying ONLY the transparent/colorless phrases */}
                            <div className="bg-transparent border-0 shadow-none max-w-2xl w-full flex flex-col items-center justify-center animate-scale-up">
                              
                              <div className="flex flex-col gap-5 w-full max-h-[250px] overflow-y-auto pr-1 items-center justify-center">
                                {questions.map((q, idx) => {
                                  const isViewed = viewedSlots.includes(q.id);
                                  return (
                                    <button
                                      key={q.id}
                                      onClick={() => {
                                        setVideoFinished(false);
                                        setActiveVideoSlot(q.id);
                                      }}
                                      disabled={!q.videoUrl}
                                      className={`relative bg-transparent border-0 shadow-none p-1 text-center transition-all duration-300 cursor-pointer outline-none focus:outline-none flex flex-col items-center justify-center select-none`}
                                    >
                                      {/* Phrase only, with deep drop shadow for perfect readability on video overlays */}
                                      <p className={`font-display font-black text-sm md:text-base uppercase tracking-widest transition-all ${
                                        isViewed
                                          ? "text-zinc-500 filter blur-[0.8px] hover:blur-none"
                                          : "text-[#00FF55] hover:scale-110 active:scale-95"
                                      } [text-shadow:0_2px_10px_rgba(0,0,0,1)]`}>
                                        🎤 "{q.phrase}"
                                      </p>
                                    </button>
                                  );
                                })}
                              </div>

                              {/* Action buttons requested by the user: Rever Vídeo & Iniciar do Zero */}
                              <div className="flex flex-wrap items-center justify-center gap-4 mt-8 w-full">
                                <button
                                  onClick={() => {
                                    setVideoFinished(false);
                                    if (videoRef.current) {
                                      videoRef.current.currentTime = 0;
                                      const playPromise = videoRef.current.play();
                                      if (playPromise !== undefined) {
                                        playPromise.catch(err => console.warn("Failed to play: ", err));
                                      }
                                    }
                                  }}
                                  className="flex items-center gap-2 px-5 py-2.5 bg-zinc-950/95 border-2 border-black hover:border-zinc-700 text-white font-mono text-[10px] font-bold uppercase rounded-xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 active:translate-y-0.5 active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] transition-all duration-200 cursor-pointer"
                                >
                                  <RotateCcw className="w-3.5 h-3.5 text-zinc-400" />
                                  <span>Rever Vídeo</span>
                                </button>

                                <button
                                  onClick={() => {
                                    setViewedSlots([]);
                                    setVideoFinished(false);
                                    setActiveVideoSlot("intro");
                                  }}
                                  className="flex items-center gap-2 px-5 py-2.5 bg-[#00FF55] hover:bg-[#00FF55]/90 text-black border-2 border-black font-mono text-[10px] font-black uppercase rounded-xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 active:translate-y-0.5 active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] transition-all duration-200 cursor-pointer"
                                >
                                  <Play className="w-3.5 h-3.5 fill-black" />
                                  <span>Iniciar do Zero</span>
                                </button>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Video Controls bar inside iframe overlay */}
                        {!isIntroSpecialVideo && (
                          <div className="absolute bottom-3 left-3 z-10 bg-black/85 border border-[#00FF55]/40 text-[#00FF55] text-[10px] font-mono px-2.5 py-1 rounded flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#00FF55] animate-pulse" />
                            <span>MÍDIA LOCAL ATIVA</span>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="p-8 text-center max-w-sm flex flex-col items-center gap-4 bg-white/5 backdrop-blur-md text-zinc-300">
                        <div className="w-16 h-16 rounded-full bg-zinc-900 border-2 border-[#00FF55] flex items-center justify-center shadow-[0_0_15px_rgba(0,255,85,0.25)] animate-pulse">
                          <Video className="w-7 h-7 text-[#00FF55]" />
                        </div>
                        <div className="space-y-2">
                          <h4 className="font-bold text-sm text-white uppercase tracking-wider">Nenhum Vídeo Carregado nesta Rota</h4>
                          <p className="text-xs text-zinc-400 leading-relaxed">
                            Vá no menu de <span className="text-[#00FF55] font-bold cursor-pointer underline" onClick={() => setActiveTab("settings")}>Configurações</span> para carregar os seus vídeos locais e sintonizar os gatilhos corretamente.
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Sub-system Alerts inside screen */}
                    {videoPlayError && (
                      <div className="absolute inset-0 bg-white/95 flex flex-col items-center justify-center p-5 text-center z-10 border-2 border-red-500">
                        <AlertTriangle className="w-8 h-8 text-red-500 mb-1" />
                        <span className="text-[10px] font-mono font-bold text-red-600 block">FALHA DE CARREGAMENTO</span>
                        <p className="text-[11px] text-zinc-600 max-w-xs mt-1 leading-normal font-sans">
                          {videoPlayError}
                        </p>
                        <button
                          onClick={() => setVideoPlayError("")}
                          className="mt-3 px-3 py-1 bg-black text-[#00FF55] hover:bg-zinc-800 text-[10px] font-mono font-bold rounded-lg transition-all border border-black cursor-pointer"
                        >
                          IGNORAR
                        </button>
                      </div>
                    )}
                    
                    {/* Active Route Slot Indicators on the bottom right corner */}
                    <div className="absolute bottom-3 right-3 z-10 flex flex-wrap gap-1 bg-white/95 p-1 rounded-lg border border-black text-[10px] font-mono shadow-sm max-w-[180px]">
                      <button
                        onClick={() => setActiveVideoSlot("intro")}
                        disabled={!introUrl}
                        className={`px-2 py-0.5 rounded font-bold transition-all disabled:opacity-30 disabled:cursor-not-allowed ${activeVideoSlot === "intro" ? "bg-[#00FF55] text-black border-2 border-black" : "text-zinc-600"}`}
                        title="Ir para o vídeo inicial"
                      >
                        Intro
                      </button>
                      {questions.map((q, idx) => (
                        <button
                          key={q.id}
                          onClick={() => setActiveVideoSlot(q.id)}
                          disabled={!q.videoUrl}
                          className={`px-2 py-0.5 rounded font-bold transition-all disabled:opacity-30 disabled:cursor-not-allowed ${activeVideoSlot === q.id ? "bg-[#00FF55] text-black border-2 border-black" : "text-zinc-600"}`}
                          title={`Canal da Pergunta ${idx + 1}`}
                        >
                          Q{idx + 1}
                        </button>
                      ))}
                    </div>

                  </div>

                </div>

              </div>

              {/* Seamless Voice Chat & Manual Companion Box - Centered at the Bottom */}
              <div className="bg-zinc-900/40 backdrop-blur-md border-3 border-black rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] text-left flex flex-col md:flex-row gap-6 items-stretch">
                
                {/* Speaking Control Badge */}
                <div className="bg-zinc-950/60 border-2 border-zinc-800/80 rounded-2xl p-6 flex flex-col items-center justify-center text-center gap-4 min-w-[220px] shrink-0">
                  
                  {/* Large Speak Button */}
                  <button
                    onClick={toggleListening}
                    className={`w-16 h-16 rounded-full flex items-center justify-center transition-all border-3 border-black cursor-pointer ${
                      isListening
                        ? "bg-red-500 text-white shadow-[0_0_15px_rgba(239,68,68,0.4)] animate-pulse"
                        : "bg-[#00FF55] text-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:translate-y-[1px] hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-y-[3px] active:shadow-none"
                    }`}
                    title={isListening ? "Desativar escuta de voz" : "Ativar assistente para ouvir"}
                  >
                    {isListening ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                  </button>

                  <div className="space-y-1">
                    {isListening ? (
                      <div className="space-y-2">
                        <span className="text-[10px] font-mono font-bold text-red-500 uppercase tracking-wider block animate-pulse">
                          ESCUTA ATIVA...
                        </span>
                        
                        {/* Interactive audio lightbars */}
                        <div className="flex items-end justify-center gap-1 h-5 pt-1">
                          <div className="w-1 bg-red-400 rounded-full v-wave-1" />
                          <div className="w-1 bg-[#00FF55] rounded-full border border-black v-wave-2" />
                          <div className="w-1 bg-[#00FF55] rounded-full border border-black v-wave-3" />
                          <div className="w-1 bg-red-400 rounded-full v-wave-4" />
                        </div>
                      </div>
                    ) : isAnalyzing ? (
                      <span className="text-xs font-bold text-zinc-300 animate-pulse block">
                        Analisando frequências...
                      </span>
                    ) : (
                      <div className="flex flex-col items-center gap-1.5">
                        <span className="text-xs font-bold text-zinc-400 block">
                          Fale para interagir
                        </span>
                        <div className="flex items-center gap-1.5 text-xs font-mono bg-zinc-900 border border-zinc-800 px-2 py-0.5 rounded-md">
                          <span className={`w-2 h-2 rounded-full border border-black/25 ${isListening ? "bg-red-500 animate-pulse" : "bg-[#00FF55]"}`} />
                          <span className="font-bold text-[9px] text-zinc-400">SINTONIZADO</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {speechError && (
                    <div className="w-full p-2 bg-red-950/40 border border-red-900/50 text-[10px] text-red-400 rounded font-mono">
                      {speechError}
                    </div>
                  )}

                </div>

                {/* Speech transcript & manual fallback */}
                <div className="flex-1 flex flex-col justify-between gap-4">
                  
                  {/* Real-time Subtitles / Message Box */}
                  <div className="bg-zinc-950/60 border-2 border-zinc-800/80 rounded-2xl p-5 text-xs flex-1 flex flex-col justify-center">
                    <div>
                      <span className="text-[9px] text-zinc-500 font-mono block uppercase font-bold tracking-wider mb-2">
                        {isListening ? "Transcrição em Tempo Real:" : "Você perguntou:"}
                      </span>
                      <p className={`font-display font-extrabold italic text-sm mt-0.5 transition-all ${isListening ? "text-[#00FF55] bg-[#00FF55]/10 border border-dashed border-[#00FF55]/30 px-3 py-2 rounded animate-pulse" : "text-zinc-100"}`}>
                        {isListening 
                          ? (realtimeSpeech ? `"${realtimeSpeech}"` : "Ouvindo atentamente... fale algo") 
                          : (lastSpeechDetected ? `"${lastSpeechDetected}"` : "Aguardando transmissão de voz...")
                        }
                      </p>
                    </div>
                  </div>

                  {/* Backup input bar */}
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      handleIncomingCommand(inputText);
                    }}
                    className="relative"
                  >
                    <input
                      type="text"
                      className="w-full bg-zinc-950 border-2 border-zinc-800 focus:ring-0 focus:border-[#00FF55] rounded-xl pl-3.5 pr-11 py-2.5 text-xs text-zinc-150 placeholder-zinc-500 font-mono shadow-[2px_2px_0px_0px_rgba(0,0,0,0.5)] focus:outline-none transition-all"
                      placeholder="Escreva a pergunta correspondente aqui..."
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      disabled={isAnalyzing}
                    />
                    <button
                      type="submit"
                      disabled={isAnalyzing || !inputText.trim()}
                      className="absolute right-1.5 top-1.5 w-7.5 h-7.5 rounded bg-[#00FF55] border border-black hover:bg-black hover:text-[#00FF55] transition-all flex items-center justify-center cursor-pointer shadow-sm"
                    >
                      <Send className="w-3 h-3" />
                    </button>
                  </form>

                </div>

              </div>

            </div>

            {/* Minimalist Configuration Action Bar */}
            {!hidePanels && (
              <div className="bg-zinc-900/20 backdrop-blur-md rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between border border-zinc-800/80 gap-4 text-left max-w-5xl mx-auto w-full">
                <div className="flex items-center gap-3">
                  <div className="bg-zinc-950 border border-zinc-800 text-[10px] h-6 px-2.5 rounded-lg font-mono text-zinc-400 font-bold flex items-center shrink-0">
                    SISTEMA ATIVO
                  </div>
                  <p className="text-[11px] text-zinc-400 leading-none font-mono">
                    Gatilhos de voz sintonizados e prontos para interação.
                  </p>
                </div>

                <button
                  onClick={() => setActiveTab("settings")}
                  className="bg-zinc-950 hover:bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-2 font-mono text-[10px] font-bold text-[#00FF55] hover:border-[#00FF55]/35 transition-all cursor-pointer shadow-sm flex items-center gap-2 uppercase tracking-wider"
                >
                  <Settings className="w-3.5 h-3.5" />
                  <span>Configurar Canais</span>
                </button>
              </div>
            )}

          </div>
        )}

        {/* VIEW 2: AJUSTES DA CENTRAL (Optimized, Simplified and Professional Settings Tab) */}
        {activeTab === "settings" && (
          <div className="space-y-6 animate-fade-in">
            
            <div className="bg-zinc-950 border-3 border-black rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] text-left flex flex-col gap-6 text-zinc-100">
              
              {/* Header section with clean typography & solid controls */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-900 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] font-mono font-bold bg-[#00FF55] text-black border border-black px-2 py-0.5 rounded uppercase">
                      Painel do Operador
                    </span>
                    <span className="text-[9px] font-mono font-bold bg-zinc-900 text-zinc-400 border border-zinc-800 px-2 py-0.5 rounded uppercase">
                      v2.1
                    </span>
                  </div>
                  <h2 className="text-sm font-display font-black text-white uppercase tracking-wider mt-1.5">
                    Configuração de Canais e Voz
                  </h2>
                  <p className="text-[11px] text-zinc-400 mt-0.5 font-mono">
                    Gerencie a transmissão e associe comandos falados aos canais de vídeo.
                  </p>
                </div>
                
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={resetAllTriggers}
                    className="flex items-center gap-1.5 bg-zinc-900 hover:bg-zinc-850 text-zinc-400 hover:text-zinc-200 text-[10px] font-bold px-3 py-2 rounded-lg border border-zinc-800 transition-all cursor-pointer shadow-sm font-mono uppercase"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Redefinir</span>
                  </button>

                  <button
                    onClick={() => setActiveTab("chat")}
                    className="flex items-center gap-1.5 bg-[#00FF55] text-black hover:bg-[#00FF55]/85 text-[10px] font-black px-4 py-2 rounded-lg transition-all cursor-pointer uppercase font-mono tracking-wider shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]"
                  >
                    <span>Concluído</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* 12-Column Grid Layout for Settings Panel */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

                {/* Left Side: System & Intro Flow (Col Span: 4) */}
                <div className="lg:col-span-4 space-y-5">
                  
                  {/* Card 1: Intro Video config */}
                  <div className="bg-zinc-900/40 border border-zinc-900 rounded-2xl p-4 flex flex-col justify-between gap-4 text-left">
                    <div>
                      <div className="flex justify-between items-center border-b border-zinc-900 pb-2">
                        <span className="text-[11px] font-mono font-bold text-zinc-200 uppercase tracking-wide flex items-center gap-1.5">
                          <Video className="w-3.5 h-3.5 text-[#00FF55]" />
                          Vídeo de Apresentação (Intro)
                        </span>
                        {introUrl && (
                          <span className="text-[8px] bg-[#00FF55]/10 text-[#00FF55] px-1.5 py-0.5 rounded font-extrabold font-mono border border-[#00FF55]/20">
                            ATIVO
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-zinc-500 leading-normal mt-2 font-mono">
                        Vídeo padrão reproduzido na inicialização ou ao recomeçar a visita guiada.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <label className="border border-dashed border-zinc-800 hover:border-[#00FF55]/50 bg-zinc-950/80 rounded-xl p-4 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-1 min-h-[90px]">
                        <input
                          type="file"
                          accept="video/*"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleFileChange("intro", file);
                          }}
                          className="hidden"
                        />
                        <Upload className="w-4 h-4 text-zinc-650 mb-0.5" />
                        {introName ? (
                          <span className="text-[#00FF55] font-bold max-w-full truncate block px-1 text-[10px] font-mono">
                            {introName}
                          </span>
                        ) : (
                          <span className="text-zinc-500 font-mono text-[10px]">Importar arquivo (.mp4)</span>
                        )}
                      </label>

                      <button
                        type="button"
                        onClick={() => {
                          if (introUrl) {
                            setActiveVideoSlot("intro");
                            setActiveTab("chat");
                          }
                        }}
                        disabled={!introUrl}
                        className="w-full flex items-center justify-center gap-1 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-850 active:bg-zinc-950 border border-zinc-800 rounded-lg text-zinc-300 hover:text-[#00FF55] disabled:opacity-35 disabled:pointer-events-none transition-all cursor-pointer font-bold font-mono text-[9px] uppercase shadow-sm"
                      >
                        Visualizar Intro
                      </button>
                    </div>
                  </div>

                </div>

                {/* Right Side: Voice Triggers Grid (Col Span: 8) */}
                <div className="lg:col-span-8 space-y-4">
                  
                  {/* Mini control bar */}
                  <div className="flex items-center justify-between border-b border-zinc-900 pb-2">
                    <span className="text-[11px] font-mono font-bold text-[#00FF55] uppercase tracking-wider flex items-center gap-1.5">
                      <Mic className="w-3.5 h-3.5" />
                      Gatilhos Cadastrados ({questions.length})
                    </span>
                  </div>

                  {/* Elegant Cards Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-[460px] overflow-y-auto pr-1">
                    {questions.map((q, idx) => (
                      <div
                        key={q.id}
                        className="bg-zinc-950/80 border border-zinc-900 hover:border-zinc-800 rounded-xl p-4 flex flex-col justify-between gap-3 text-left transition-all duration-200"
                      >
                        <div className="flex justify-between items-center border-b border-zinc-900 pb-2">
                          <span className="text-[10px] font-mono font-bold text-zinc-400 uppercase tracking-wide">
                            Canal #{idx + 1}
                          </span>
                          <div className="flex items-center gap-1.5">
                            {q.videoUrl && (
                              <span className="text-[8px] bg-[#00FF55]/10 text-[#00FF55] px-1.5 py-0.5 rounded font-extrabold font-mono border border-[#00FF55]/20">
                                ATIVO
                              </span>
                            )}
                            <button
                              type="button"
                              onClick={() => removeQuestion(q.id)}
                              className="text-zinc-550 hover:text-red-400 transition-colors p-1 cursor-pointer"
                              title="Excluir Gatilho"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        <div className="space-y-3">
                          
                          {/* Phrase input */}
                          <div className="space-y-1">
                            <label className="text-[9px] text-zinc-500 uppercase font-mono font-bold block">
                              Frase Ativadora:
                            </label>
                            <input
                              type="text"
                              className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#00FF55] rounded-lg px-2.5 py-1.5 text-[11px] text-zinc-100 focus:outline-none font-bold font-mono"
                              value={q.phrase}
                              onChange={(e) => updateQuestionPhrase(q.id, e.target.value)}
                              placeholder="Ex: mostrar floresta"
                            />
                          </div>

                          {/* Video file input */}
                          <div className="space-y-1">
                            <label className="text-[9px] text-zinc-500 uppercase font-mono font-bold block">
                              Vídeo Local (.mp4):
                            </label>
                            <label className="border border-dashed border-zinc-800 hover:border-[#00FF55]/50 bg-zinc-950/60 rounded-lg p-2 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-1 min-h-[55px]">
                              <input
                                type="file"
                                accept="video/*"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) handleFileChange(q.id, file);
                                }}
                                className="hidden"
                              />
                              <Upload className="w-3.5 h-3.5 text-zinc-650" />
                              {q.videoName ? (
                                <span className="text-[#00FF55] font-bold max-w-full truncate block px-1 text-[9px] font-mono">
                                  {q.videoName}
                                </span>
                              ) : (
                                <span className="text-zinc-500 font-mono text-[9px]">Importar arquivo</span>
                              )}
                            </label>
                          </div>

                          {/* Trigger test button */}
                          <button
                            type="button"
                            onClick={() => {
                              if (q.videoUrl) {
                                setActiveVideoSlot(q.id);
                                setActiveTab("chat");
                              }
                            }}
                            disabled={!q.videoUrl}
                            className="w-full flex items-center justify-center gap-1 px-2.5 py-1.5 bg-zinc-900 hover:bg-zinc-850 active:bg-zinc-950 border border-zinc-800 rounded-lg text-zinc-350 hover:text-[#00FF55] disabled:opacity-35 disabled:pointer-events-none transition-all cursor-pointer font-bold font-mono text-[9px] uppercase shadow-sm"
                          >
                            Testar Canal
                          </button>
                        </div>
                      </div>
                    ))}

                    {/* Streamlined "Add" card trigger slot */}
                    <button
                      type="button"
                      onClick={addQuestion}
                      className="border border-dashed border-zinc-800 hover:border-[#00FF55]/50 rounded-xl p-4 flex flex-col justify-center items-center gap-2 hover:bg-zinc-900/25 transition-all cursor-pointer text-zinc-500 hover:text-zinc-300 min-h-[190px]"
                    >
                      <div className="w-10 h-10 rounded-full border border-dashed border-zinc-800 flex items-center justify-center text-zinc-500 group-hover:border-zinc-300">
                        <span className="text-base leading-none font-bold">+</span>
                      </div>
                      <div className="text-center">
                        <span className="text-[11px] font-bold uppercase tracking-wider font-mono block text-zinc-300">Novo Gatilho</span>
                        <span className="text-[9px] text-zinc-500 mt-1 max-w-[170px] block mx-auto leading-normal font-mono">
                          Associe um novo arquivo de vídeo a um comando.
                        </span>
                      </div>
                    </button>
                  </div>

                </div>

              </div>

            </div>

          </div>
        )}

      </main>

      {/* Clean Aesthetic Footer */}
      {!hidePanels && (
        <footer id="ecobot-footer" className="mt-auto py-6 border-t border-zinc-900 bg-zinc-950/80">
          <div className="max-w-5xl mx-auto px-6 flex flex-col sm:flex-row justify-between items-center text-[10px] font-mono text-zinc-650 gap-2">
            <span>ASSISTENTE WIT — PORTAL DE SUSTENTABILIDADE</span>
            <span>© CONEXÃO INTERATIVA DE VÍDEO</span>
          </div>
        </footer>
      )}

      {/* Floating Action Button to Restore Panels & Restart (Visible only when panels are hidden) */}
      {hidePanels && (
        <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-[600px] max-w-full h-24 bg-transparent flex items-end pb-4 justify-center pointer-events-auto z-50 group select-none">
          <div className="opacity-0 translate-y-3 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300 flex flex-wrap gap-4 justify-center">
            <button
              onClick={() => setHidePanels(false)}
              className="flex items-center gap-2.5 px-5 py-3.5 bg-black text-[#00FF55] hover:bg-[#00FF55] hover:text-black font-display font-black text-xs uppercase tracking-widest rounded-full border-3 border-black shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] hover:translate-y-[1px] hover:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] active:translate-y-[2px] active:shadow-none transition-all duration-300 cursor-pointer text-glow-emerald hover:text-glow-none"
              title="Mostrar Chat, Configurações e todos os controles de volta"
            >
              <Eye className="w-4 h-4 animate-pulse" />
              <span>Retornar com o Painel</span>
            </button>

            <button
              onClick={() => {
                setHasStarted(false);
                setHidePanels(false);
              }}
              className="flex items-center gap-2.5 px-5 py-3.5 bg-black text-rose-500 hover:bg-rose-500 hover:text-white font-display font-black text-xs uppercase tracking-widest rounded-full border-3 border-black shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] hover:translate-y-[1px] hover:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] active:translate-y-[2px] active:shadow-none transition-all duration-300 cursor-pointer"
              title="Reiniciar toda a experimentação e voltar para a tela inicial"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reiniciar Experimentação</span>
            </button>
          </div>
        </div>
      )}


      {/* Floating Microphone Action Button */}
      {activeTab === "chat" && hasStarted && (
        <div className="fixed bottom-6 right-6 z-[45] flex flex-col items-end gap-1.5 pointer-events-auto animate-fade-in">
          <div className="flex items-center gap-1.5 bg-zinc-950/95 border-2 border-black px-2.5 py-1 rounded-full shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] text-[8px] font-mono font-bold uppercase transition-all duration-300">
            <span className={`w-1.5 h-1.5 rounded-full ${isListening ? "bg-red-500 animate-pulse" : "bg-[#00FF55]"}`} />
            <span className={isListening ? "text-red-400 font-extrabold animate-pulse" : "text-zinc-400"}>
              {isListening ? "ESCUTA ATIVA" : "CLIQUE P/ FALAR"}
            </span>
          </div>
          <button
            onClick={toggleListening}
            className={`w-14 h-14 rounded-full flex items-center justify-center transition-all border-3 border-black cursor-pointer shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 active:translate-y-1 active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] ${
              isListening
                ? "bg-red-500 text-white shadow-[0_0_15px_rgba(239,68,68,0.45)]"
                : "bg-[#00FF55] text-black hover:bg-[#00FF55]/90"
            }`}
            title={isListening ? "Desativar escuta de voz" : "Ativar microfone por voz"}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5 animate-pulse" />}
          </button>
        </div>
      )}


      {/* Custom Confirmation Dialog Modal */}
      {confirmModal && confirmModal.isOpen && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-[9999] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-zinc-950 border-3 border-black rounded-3xl w-full max-w-md p-6 flex flex-col gap-4 text-zinc-100 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] text-left">
            <h3 className="font-display font-black text-sm uppercase tracking-wider text-[#00FF55] border-b border-zinc-900 pb-2">
              {confirmModal.title}
            </h3>
            <p className="text-xs text-zinc-300 font-mono leading-relaxed">
              {confirmModal.message}
            </p>
            <div className="flex justify-end gap-3 mt-2">
              <button
                type="button"
                onClick={() => setConfirmModal(null)}
                className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-mono text-[10px] font-bold uppercase rounded-lg border border-zinc-800 transition-all cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  confirmModal.onConfirm();
                  setConfirmModal(null);
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-mono text-[10px] font-black uppercase rounded-lg border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:translate-y-[0.5px] hover:shadow-[1.5px_1.5px_0px_0px_rgba(0,0,0,1)] active:translate-y-[1px] active:shadow-none transition-all cursor-pointer"
              >
                Confirmar
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
