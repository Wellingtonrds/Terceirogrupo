import fs from 'fs';

const content = fs.readFileSync('src/App.tsx', 'utf8');
const lines = content.split(/\r?\n/);

let divCount = 0;
const stack: { line: number; text: string }[] = [];

for (let i = 1176; i < 1709; i++) {
  const lineNum = i + 1;
  const line = lines[i];
  
  const tagRegex = /<\/?div(?:\s+[^>]*?)?>/g;
  let match;
  while ((match = tagRegex.exec(line)) !== null) {
    const fullTag = match[0];
    if (fullTag.endsWith('/>')) continue; // self-closing
    
    if (fullTag.startsWith('</')) {
      if (stack.length === 0) {
        console.log(`EXTRA closing </div> on line ${lineNum}: ${line.trim()}`);
      } else {
        stack.pop();
        divCount--;
      }
    } else {
      stack.push({ line: lineNum, text: line.trim() });
      divCount++;
    }
  }
}

console.log(`\nFinal open divs in settings block: ${divCount}`);
stack.forEach(d => {
  console.log(`- Opened on line ${d.line}: ${d.text}`);
});
