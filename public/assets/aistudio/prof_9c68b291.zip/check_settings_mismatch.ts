import fs from 'fs';

const content = fs.readFileSync('src/App.tsx', 'utf8');
const lines = content.split(/\r?\n/);
const stack: { tag: string; line: number; text: string }[] = [];

// Only track standard structural tags
const trackedTags = ['div', 'main', 'footer', 'form', 'span', 'button', 'td', 'tr', 'tbody', 'table', 'label'];

// Scan lines from 1177 (index 1176) to 1715 (index 1714)
for (let i = 1176; i <= 1714; i++) {
  const lineNum = i + 1;
  const line = lines[i].trim();
  
  if (line.startsWith('//') || line.startsWith('/*')) continue;
  
  const tagRegex = /<\/?([a-zA-Z0-9]+)(?:\s+[^>]*?)?>/g;
  let match;
  while ((match = tagRegex.exec(lines[i])) !== null) {
    const fullTag = match[0];
    const tagName = match[1];
    
    if (!trackedTags.includes(tagName)) continue;
    if (fullTag.endsWith('/>')) continue;
    
    const isClosing = fullTag.startsWith('</');
    
    if (isClosing) {
      if (stack.length === 0) {
        console.log(`Unmatched closing tag ${fullTag} on line ${lineNum}`);
      } else {
        const top = stack.pop()!;
        if (top.tag !== tagName) {
          console.log(`Mismatch on line ${lineNum}: closed </${tagName}> but expected </${top.tag}> (opened on line ${top.line})`);
          // Put the expected one back to keep checking
          stack.push(top);
        } else {
          console.log(`Match: </${tagName}> on line ${lineNum} closed <${top.tag}> from line ${top.line}`);
        }
      }
    } else {
      stack.push({ tag: tagName, line: lineNum, text: line });
      console.log(`Open: <${tagName}> on line ${lineNum}`);
    }
  }
}

console.log("\nREMAINING OPEN TAGS IN STACK:");
while (stack.length > 0) {
  const top = stack.pop()!;
  console.log(`- <${top.tag}> opened on line ${top.line}: ${top.text}`);
}
